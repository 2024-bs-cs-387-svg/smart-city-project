# 🔌 Arduino UNO — COMPLETE Wiring Guide

**Modules:** Traffic (2 lanes) + Waste (2 bins) + Park (2 zones)
**Total Sensors:** 4× HC-SR04 + 2× Soil + 6× LEDs + 2× Relays

---

## 📋 Final Arduino UNO Pin Assignments

| Pin | Component | Type |
|---|---|---|
| **Pin 2** | 🔴 **SHARED TRIG** (all 4 HC-SR04) | Output |
| **Pin 3** | HC-SR04 Lane A — ECHO | Input |
| **Pin 4** | Red LED — Lane A (INT-A) | Output |
| **Pin 5** | Yellow LED — Lane A | Output |
| **Pin 6** | Green LED — Lane A | Output |
| **Pin 7** | Red LED — Lane B (INT-B) | Output |
| **Pin 8** | Yellow LED — Lane B | Output |
| **Pin 9** | Pump A Relay — IN | Output |
| **Pin 10** | Pump B Relay — IN | Output |
| **Pin 11** | **TX → ESP D8** (voltage divider) | Serial |
| **Pin 12** | **RX ← ESP D7** (direct) | Serial |
| **Pin 13** | HC-SR04 Lane B — ECHO | Input |
| **A0** | Soil Sensor Zone A — AO | Analog |
| **A1** | Soil Sensor Zone B — AO | Analog |
| **A2** | Green LED — Lane B | Output |
| **A4** | HC-SR04 Bin 1 — ECHO | Input |
| **A5** | HC-SR04 Bin 2 — ECHO | Input |
| **5V** | Power rail | Power |
| **GND** | Ground rail | Ground |

---

## ⚡ SHARED TRIG Concept — Important!

**Normal way:** 4 HC-SR04 sensors = 8 pins (4 TRIG + 4 ECHO) ❌
**Smart trick:** 1 shared TRIG + 4 ECHO = 5 pins ✅

### Practical breadboard setup:

```
Arduino Pin 2 ────┬──── Lane A TRIG
                  ├──── Lane B TRIG
                  ├──── Bin 1 TRIG
                  └──── Bin 2 TRIG
```

**Breadboard pe kaise karo:**

1. Pin 2 se ek wire breadboard ki kisi row pe lagao (jaise row 20)
2. Us row se **4 alag wires** nikal ke har HC-SR04 ke TRIG pin pe le jao

---

## 🚦 STEP 1 — Traffic Lane A (HC-SR04)

Sensor connections:

| HC-SR04 Pin | Arduino |
|---|---|
| **VCC** | Arduino **5V** (breadboard red rail) |
| **GND** | Arduino **GND** (blue rail) |
| **TRIG** | Arduino **Pin 2** (shared) |
| **ECHO** | Arduino **Pin 3** |

**Sensor placement:** Road ke upar lagao, neeche face kare (10-20 cm height).

---

## 🚦 STEP 2 — Traffic Lane B (HC-SR04)

| HC-SR04 Pin | Arduino |
|---|---|
| **VCC** | Arduino **5V** |
| **GND** | Arduino **GND** |
| **TRIG** | Arduino **Pin 2** (shared — same as Lane A!) |
| **ECHO** | Arduino **Pin 13** |

---

## 🔴🟡🟢 STEP 3 — Traffic LEDs Intersection A (Lane A)

Her LED ke liye yehi circuit:

```
Arduino Pin → [1kΩ resistor] → LED (+) → LED (−) → GND
```

⚠️ **LED polarity:**
- **Lambi leg (+)** → Resistor side
- **Choti leg (−)** → GND side

| LED | Arduino Pin |
|---|---|
| 🔴 Red | **Pin 4** → 1kΩ → Red LED |
| 🟡 Yellow | **Pin 5** → 1kΩ → Yellow LED |
| 🟢 Green | **Pin 6** → 1kΩ → Green LED |

💡 Sab LEDs ki **choti legs** ek hi GND rail pe laga sakte ho.

---

## 🔴🟡🟢 STEP 4 — Traffic LEDs Intersection B (Lane B)

| LED | Arduino Pin |
|---|---|
| 🔴 Red | **Pin 7** → 1kΩ → Red LED |
| 🟡 Yellow | **Pin 8** → 1kΩ → Yellow LED |
| 🟢 Green | **A2** → 1kΩ → Green LED |

---

## ♻️ STEP 5 — Waste Bin 1 (HC-SR04)

| HC-SR04 Pin | Arduino |
|---|---|
| **VCC** | Arduino **5V** |
| **GND** | Arduino **GND** |
| **TRIG** | Arduino **Pin 2** (shared) |
| **ECHO** | Arduino **A4** |

**Sensor placement:** Bin ke dhakkan ke neeche upar lagao, neeche face kare. Bin ki empty height note karo (code mein `BIN_HEIGHT_CM = 30` hai — agar bin alag hai to code mein change karo).

---

## ♻️ STEP 6 — Waste Bin 2 (HC-SR04)

| HC-SR04 Pin | Arduino |
|---|---|
| **VCC** | Arduino **5V** |
| **GND** | Arduino **GND** |
| **TRIG** | Arduino **Pin 2** (shared) |
| **ECHO** | Arduino **A5** |

---

## 🌱 STEP 7 — Soil Sensor Zone A

### Soil sensor module ki pehchaan:

Tumhare paas **4-pin soil sensor module** hota hai (do pieces hote hain):

**Module 1 — Main control board (small PCB):**
```
  ┌─────────────────────┐
  │  [Blue trim pot]    │ ← sensitivity adjuster
  │                     │
  │  VCC  GND  DO  AO   │ ← 4 pins at bottom
  └──┬────┬────┬────┬───┘
     │    │    │    │
```

**Module 2 — Actual probe (fork-shaped):**
Do metal prongs jo soil mein dubao ge.

**Connection between modules:**
Probe ke 2 pins → Control board ke 2 pins (wire se). Aksar pehle se jude hote hain.

### Wiring — Zone A:

| Soil Module Pin | Arduino Pin | Function |
|---|---|---|
| **VCC** | Arduino **5V** | Power |
| **GND** | Arduino **GND** | Ground |
| **AO** | Arduino **A0** | Analog value (0-1023) ← **USE THIS** |
| **DO** | ❌ **Nahi lagao** | Digital on/off (not used) |

### Soil sensor kaise kaam karta hai:

- Probe soil mein dubao
- **Dry soil** → AO ~850 (high resistance)
- **Wet soil** → AO ~250 (low conductivity)
- Code automatically **0-100% moisture** mein convert karta hai

### Sensor calibration (one-time):

Code mein yeh values hain:
```cpp
#define SOIL_DRY    850   // bilkul dry soil
#define SOIL_WET    250   // poori wet soil
```

Agar tumhari values alag hain:
1. Serial Monitor kholo
2. Sensor dry mein rakho, raw value note karo → yeh `SOIL_DRY`
3. Sensor paani/wet soil mein dubao → yeh `SOIL_WET`
4. Code update karke re-upload karo

💡 **90%+ projects mein default values kaam karti hain** — calibration optional.

### ⚠️ Sensitivity pot:

Control board pe **blue screw (trim pot)** hota hai. Yeh **sirf DO pin ke liye** hai (on/off threshold). Hum AO use kar rahe hain to **pot se farak nahi padta** — jahan bhi hai theek hai.

---

## 🌱 STEP 8 — Soil Sensor Zone B

Same as Zone A, bas A0 ki jagah **A1**:

| Soil Pin | Arduino |
|---|---|
| **VCC** | Arduino **5V** |
| **GND** | Arduino **GND** |
| **AO** | Arduino **A1** |
| **DO** | ❌ nahi |

---

## 💧 STEP 9 — Pump A Relay

Relay module pe 2 sides hote hain:

### Control side (Arduino ko connect):

| Relay Pin | Arduino |
|---|---|
| **VCC** | Arduino **5V** |
| **GND** | Arduino **GND** |
| **IN** | Arduino **Pin 9** |

### Output side (actual pump):

- **COM, NO, NC** terminals hote hain (3 screws)
- **Testing ke liye:** COM aur NO ke beech ek LED laga do (battery ke saath) — relay click hone par jalegi
- **Actual pump ke liye:** External 12V power supply use karo (Arduino se pump direct mat chalao)

### Wiring for pump testing (optional — pump nahi hai to):

```
5V battery (+) → COM
NO             → LED (+) → LED (−) → GND
```

Jab relay active ho → LED jalegi

### ⚠️ Relay logic (active LOW):

Most cheap Chinese relay modules **"active LOW"** hote hain:
- IN pin pe **LOW** → Relay **ON** (click!)
- IN pin pe **HIGH** → Relay **OFF**

Code mein already handle hai:
```cpp
#define RELAY_ACTIVE_LOW true
```

Agar tumhari relay **active HIGH** hai (kuch expensive modules): to `true` ki jagah `false` kar do.

**Test karke pakka kar lo:** Pin 9 pe LOW (Pin 9 ko GND se short karo) → relay click karni chahiye.

---

## 💧 STEP 10 — Pump B Relay

Same as Pump A, bas:

| Relay Pin | Arduino |
|---|---|
| VCC | Arduino **5V** |
| GND | Arduino **GND** |
| **IN** | Arduino **Pin 10** |

---

## 🔗 STEP 11 — Arduino ↔ ESP8266 Serial (3 wires)

**Yeh bohot important step hai — galat kiya to ESP burn ho sakta hai!**

### Wire 1: Arduino Pin 12 ← ESP D7 (direct, NO divider)

```
ESP D7  ──────── Arduino Pin 12
```

- ESP 3.3V signal bhejta hai
- Arduino 5V input pin 3.3V safely read karta hai
- **No voltage divider needed**

### Wire 2: Arduino Pin 11 → ESP D8 (VOLTAGE DIVIDER ZARURI!)

⚠️ Arduino 5V hai. Agar direct ESP D8 (3.3V) pe lagao to **ESP burn hoga!**

```
Arduino Pin 11 ──[1kΩ]──┬──── ESP D8
                        │
                     [2kΩ]
                        │
                       GND
```

**Breadboard pe practical setup:**

1. Pin 11 se wire → 1kΩ resistor ka ek end
2. 1kΩ ka doosra end → breadboard ki row (**junction point**)
3. Is junction se ek wire → ESP D8
4. Is junction se 2kΩ resistor ka ek end
5. 2kΩ ka doosra end → GND rail

**2kΩ resistor nahi hai?** Koi baat nahi:
- 2 × 1kΩ resistors **series** mein lagao (ek ke baad ek) = 2kΩ
- Ya 1 × 1kΩ + 1 × 1kΩ = 2kΩ

### Wire 3: Common GND (BILKUL ZARURI!)

```
Arduino GND ←──────→ ESP GND
```

Bas ek simple jumper wire — Arduino ke GND pin se ESP ke GND pin tak.

**Bina GND wire ke serial communication kaam NAHI karegi!**

---

## 📋 Complete Wiring Reference

```
═══════ POWER RAILS ═══════
Arduino 5V   → Breadboard RED rail  (+)
Arduino GND  → Breadboard BLUE rail (−)
Saare sensors VCC red rail se, GND blue rail se.

═══════ 4 HC-SR04 SENSORS (shared TRIG) ═══════
Arduino Pin 2 → branch to:
  ├── Lane A TRIG  (ECHO: Pin 3)
  ├── Lane B TRIG  (ECHO: Pin 13)
  ├── Bin 1 TRIG   (ECHO: A4)
  └── Bin 2 TRIG   (ECHO: A5)

═══════ TRAFFIC LEDs ═══════
Pin 4  → [1kΩ] → 🔴 Red A    → GND
Pin 5  → [1kΩ] → 🟡 Yellow A → GND
Pin 6  → [1kΩ] → 🟢 Green A  → GND
Pin 7  → [1kΩ] → 🔴 Red B    → GND
Pin 8  → [1kΩ] → 🟡 Yellow B → GND
A2     → [1kΩ] → 🟢 Green B  → GND

═══════ PARK SOIL SENSORS ═══════
Soil A: VCC→5V  GND→GND  AO→A0  (DO unused)
Soil B: VCC→5V  GND→GND  AO→A1  (DO unused)

═══════ PARK PUMP RELAYS ═══════
Relay A: VCC→5V  GND→GND  IN→Pin 9
Relay B: VCC→5V  GND→GND  IN→Pin 10

═══════ SERIAL to ESP8266 ═══════
Pin 11 → [1kΩ]─┬─ ESP D8    ← voltage divider!
               └─ [2kΩ] → GND
Pin 12 ← ESP D7            ← direct
Arduino GND ↔ ESP GND      ← common ground ZARURI
```

---

## ⚠️ Upload Instructions — Step by Step

### Pehle (Arduino code upload karne se pehle):

1. **Pin 11 ki wire ESP D8 se nikal do** (voltage divider wali)
   - Reason: Upload ke time Pin 11 USB serial se conflict karti hai
2. Arduino ko USB se laptop pe lagao

### Upload process:

3. Arduino IDE kholo
4. File → Open → `smartcity_arduino_v3.ino`
5. **Tools → Board → Arduino UNO** (NodeMCU nahi!)
6. **Tools → Port → Arduino ka COM port** (ESP wala nahi)
7. Upload button ⬆️ dabao
8. "Done uploading" wait karo

### Upload ke baad:

9. **Pin 11 ki wire wapas ESP D8 pe lagao** (through voltage divider)
10. Dono boards (Arduino + ESP) power do

---

## 🧪 Testing Order — Step by Step

### Test 1: Arduino alone (ESP abhi disconnect rakho)

1. Arduino USB se connected
2. Serial Monitor kholo (**9600 baud** — important!)
3. Expected output:
```
=== SMART CITY Arduino UNO v3.1 ===
4 HC-SR04 sensors: Lane A, Lane B, Bin 1, Bin 2
Shared TRIG pin 2 + separate ECHO pins
Soil sensors warming up...
Ready! Soil A:0% B:0%
```

### Test 2: Traffic LEDs cycle

30 seconds wait karo — LEDs ka auto cycle dikhega:
- 🟢 Green A (15-60s based on density) → 🟡 Yellow A (3s)
- 🟢 Green B (15-60s density) → 🟡 Yellow B (3s)
- Repeat

Jab Lane A green hai, Lane B ki Red on hogi (aur vice versa).

### Test 3: Lane A vehicle detection

Hath ya cheez **Lane A ke HC-SR04 sensor (Pin 3 wala) ke saamne** hilao:
```
[Traffic A] Vehicle! Total:1  PerMin:1
```

### Test 4: Lane B vehicle detection

Hath **Lane B ke HC-SR04 (Pin 13 wala) ke saamne** hilao:
```
[Traffic B] Vehicle! Total:1  PerMin:1
```

### Test 5: Waste bin detection

Hath **Bin 1 aur Bin 2 sensors** ke saamne laao. Serial mein percentage dekho:
```
[Send] Soil A:0 B:0 | Sig:GREEN_A | Lane A:1/min B:0/min | Bin1:42% Bin2:15%
```

### Test 6: Soil sensor

Zone A probe ko paani mein dubao (ya thoda gila kapda lagao):
- Dry: ~0-20%
- Moist: ~30-60%
- Wet: ~70-100%

### Test 7: Relay manual commands

Serial Monitor mein type karke Enter dabao:

| Type | Action |
|---|---|
| `a1` | Pump A ON (Pin 9 relay click) |
| `a0` | Pump A OFF |
| `b1` | Pump B ON |
| `b0` | Pump B OFF |
| `ga` | Force Green Lane A |
| `gb` | Force Green Lane B |
| `red` | All RED |
| `auto` | Back to auto mode |

### Test 8: Park auto mode

1. Serial mein `auto` type karo (Park auto mode default bhi hai)
2. Soil sensor ko dry soil mein rakho (value < 30%)
3. **Pump A relay automatically click hogi** (Pin 9)
4. Sensor gila karo (value > 75%)
5. **Pump automatically OFF** ho jayegi

### Test 9: ESP ↔ Arduino connect

1. Arduino se USB disconnect karo (power off karo)
2. **Pin 11 wapas ESP D8 pe connect karo** (voltage divider ke through)
3. **Common GND wire** check karo
4. Pin 12 ← ESP D7 confirm karo
5. Dono boards ko USB/power se chalao
6. ESP ka Serial Monitor kholo (**115200 baud**)

Expected output (every 5 sec):
```
+--- TRAFFIC (Arduino) -------------------+
| Lane A count: 5
| Per minute  : 3
| Status      : clear
| Signal      : GREEN_A
| Mode        : auto
+--- WASTE BINS (Arduino) ----------------+
| Bin 1       : 42%  (ok)
| Bin 2       : 15%  (empty)
| Alert       : None
+--- PARK WATERING (Arduino) -------------+
| Zone A      : 28%  (dry)
| Zone B      : 65%  (ok)
| Pump A      : ON
| Pump B      : OFF
| Mode        : auto
```

Top mein `| Arduino   : DATA RECEIVING` bhi dikhega ✅

### Test 10: Website control

Netlify site kholo aur dekho:

**Traffic page:**
- Lane A Count, Total Today live update hongi
- 🟢 Green Lane A button dabao → Arduino LEDs turant change
- 🔴 All Red dabao → saari LEDs red

**Waste page:**
- Bin percentages live update
- **Collect** button dabao → Bin reset to 0%

**Park page:**
- Moisture live update
- ▶ Start button → Relay click
- Auto mode mein automatic watering

---

## 🆘 Troubleshooting

| Problem | Solution |
|---|---|
| LED nahi jal rahi | Polarity check — lambi leg (+) resistor ki taraf |
| LEDs bohot dim | 220Ω resistor lagao (1kΩ ki jagah) |
| HC-SR04 galat readings | Sensor ke saamne koi obstruction? 2cm se 400cm range |
| Sab HC-SR04 0 padhte | Shared TRIG wire check karo — breadboard mein Pin 2 se 4 sensors connected? |
| Sirf ek HC-SR04 kaam kare | ECHO pin loose ho sakta hai — check individual ECHO pins |
| Soil sensor 0 dikhata | Probe soil mein properly dubaya? Dry air mein value high hogi |
| Relay click nahi hoti | VCC 5V pe hai? IN pin confirm karo. Try `a1` Serial command |
| Relay reverse logic | Code mein `RELAY_ACTIVE_LOW` false karke try karo |
| Arduino upload fail | Pin 11 wire ESP se nikalo, phir upload |
| ESP ko data nahi milta | **GND wire missing!** Dono boards ke GND connect karo |
| Signal LEDs random | Pin 11 ka voltage divider galat laga — 1kΩ + 2kΩ sahi check karo |
| Serial Monitor mein kuch nahi | Baud rate 9600 select karo (ESP ka 115200 hai) |

---

## 🎯 Final Checklist

- [ ] Pin 2 se 4 HC-SR04 ke TRIG pins sab connected
- [ ] Pin 3, 13, A4, A5 pe alag-alag ECHO pins
- [ ] 6 LEDs + 6 resistors (1kΩ each)
- [ ] 2 Soil sensors (AO pins sirf, DO nahi)
- [ ] 2 Relays (Pin 9, Pin 10)
- [ ] Pin 11 → 1kΩ → junction → 2kΩ → GND, junction to ESP D8
- [ ] Pin 12 direct to ESP D7
- [ ] Arduino GND ↔ ESP GND wire
- [ ] Both boards powered
- [ ] Arduino code uploaded (Board: UNO)
- [ ] Serial Monitor at 9600 baud for Arduino
- [ ] Serial Monitor at 115200 baud for ESP

**Sab check ho gaye to project 100% working hoga! 🎉**

---

**Koi step pe stuck ho? Screenshot aur serial output bhejo!**
