/*
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║   SMART CITY — ESP8266 NodeMCU  v7.0  (FINAL)                    ║
 * ║                                                                  ║
 * ║   Architecture: ESP + Arduino split (Arduino future-ready)       ║
 * ║                                                                  ║
 * ║   ESP8266 sensors (3.3V safe):                                   ║
 * ║    ✅ DHT22      → Weather    D4                                 ║
 * ║    ✅ YF-S201    → Water      D2                                 ║
 * ║    ✅ LDR        → Street     A0                                 ║
 * ║    ✅ PIR        → Street     D1                                 ║
 * ║    ✅ Street LED → D5  (output)                                  ║
 * ║    ✅ Serial ↔ Arduino  D7(TX)  D8(RX)                           ║
 * ║                                                                  ║
 * ║   Arduino UNO sensors (5V, future connect):                      ║
 * ║    🔜 Traffic HC-SR04 + 6 LEDs                                   ║
 * ║    🔜 Waste HC-SR04 × 2                                          ║
 * ║    🔜 Park: Soil × 2, Pump relay × 2                             ║
 * ║                                                                  ║
 * ║   Manual control from website — INSTANT via Firebase stream:     ║
 * ║    💡 Street: ON / OFF / AUTO                                    ║
 * ║    🚦 Traffic: Auto / Manual / Emergency (Arduino handles LEDs)  ║
 * ║    🌱 Park: Pumps A/B ON/OFF (Arduino handles relays)            ║
 * ║    ♻️  Waste: Collect bins (Arduino resets sensor)               ║
 * ║                                                                  ║
 * ║   Serial Monitor: Clean box format only, no scattered prints    ║
 * ║                                                                  ║
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 * ════════════════════════════════════════════════════════════════════
 *  ESP8266 WIRING
 * ════════════════════════════════════════════════════════════════════
 *
 *  DHT22:
 *    VCC → 3.3V  |  GND → GND  |  DATA → D4  |  [10kΩ: DATA↔3.3V]
 *
 *  YF-S201:
 *    RED → VIN (5V)  |  BLACK → GND  |  YELLOW → D2
 *
 *  LDR:  3.3V → [LDR] → A0 → [10kΩ] → GND
 *
 *  PIR HC-SR501:
 *    VCC → VIN (5V)  |  GND → GND  |  OUT → D1
 *
 *  Street LED:  D5 → [1kΩ] → LED(+) → LED(−) → GND
 *
 *  Arduino Serial (when you connect Arduino):
 *    ESP D7 → Arduino Pin 12 (direct, 3.3V safe)
 *    ESP D8 ← Arduino Pin 11  [VOLTAGE DIVIDER: 1kΩ + 2kΩ]
 *    ESP GND ↔ Arduino GND (common ground)
 *
 * ════════════════════════════════════════════════════════════════════
 *  LIBRARIES:
 *    WiFiManager              by tzapu
 *    Firebase ESP8266 Client  by Mobizt
 *    DHT sensor library       by Adafruit
 *    Adafruit Unified Sensor  by Adafruit
 * ════════════════════════════════════════════════════════════════════
 */

#include <ESP8266WiFi.h>
#include <WiFiManager.h>
#include <FirebaseESP8266.h>
#include <DHT.h>
#include <SoftwareSerial.h>

// ═══════════════════════════════════════════════════
//  FIREBASE CREDENTIALS
// ═══════════════════════════════════════════════════
#define FIREBASE_HOST  "https://smart-city-tuf-default-rtdb.firebaseio.com/"
#define FIREBASE_AUTH  "zCZYnlH0gKukgO9TQx9HqJIPZS31A1qkFWU8mrlp"

// ═══════════════════════════════════════════════════
//  WIFI
// ═══════════════════════════════════════════════════
#define AP_SSID    "SmartCity-Main"
#define AP_TIMEOUT 180

// ═══════════════════════════════════════════════════
//  PINS
// ═══════════════════════════════════════════════════
#define DHT_PIN     2      // D4
#define DHT_TYPE    DHT22
#define FLOW_PIN    4      // D2
#define PIR_PIN     5      // D1
#define LDR_PIN     0      // D3 (GPIO0) — digital LDR module DO pin
#define STREET_PIN 14      // D5  — Zone A (LIVE — sensor + manual)
#define ZONE_B_PIN 16      // D0  — Zone B (manual only)
#define ZONE_C_PIN 12      // D6  — Zone C (manual only — 2 LEDs parallel)
#define AR_TX      13      // D7 → Arduino Pin 12
#define AR_RX      15      // D8 ← Arduino Pin 11 [VDiv]

// ═══════════════════════════════════════════════════
//  SETTINGS
// ═══════════════════════════════════════════════════
#define FLOW_CALIBRATION      7.5f
#define FLOW_NORMAL_MIN       1.0f
#define FLOW_HIGH_THRESH     16.0f
#define FLOW_CRITICAL_THRESH 20.0f
#define FLOW_LEAK_THRESH      0.4f
#define LEAK_TIME_MS        300000UL

#define LDR_DARK_THRESHOLD    400
#define PIR_WARMUP_MS       30000UL
#define MOTION_HOLD_MS      10000UL

// ═══════════════════════════════════════════════════
//  TIMING
// ═══════════════════════════════════════════════════
#define FLOW_CALC_MS     2000UL
#define DHT_READ_MS      5000UL
#define STREET_READ_MS    500UL
#define FIREBASE_MS      3000UL
#define AR_CMD_MS        3000UL
#define HEARTBEAT_MS    10000UL
#define STATUS_PRINT_MS  5000UL
#define WIFI_RETRY_MS   30000UL
#define CMD_POLL_MS      2000UL    // Poll Firebase commands every 2 sec

// ═══════════════════════════════════════════════════
//  OBJECTS
// ═══════════════════════════════════════════════════
FirebaseData   fbData;
FirebaseData   fbStream;
FirebaseConfig fbConfig;
FirebaseAuth   fbAuth;
DHT            dht(DHT_PIN, DHT_TYPE);
WiFiManager    wifiManager;
SoftwareSerial arSerial(AR_RX, AR_TX);

// ═══════════════════════════════════════════════════
//  COMMANDS (from Firebase website)
// ═══════════════════════════════════════════════════
String cmdStreetMode    = "auto";
String cmdZoneBMode     = "off";    // Zone B manual: on/off
String cmdZoneCMode     = "off";    // Zone C manual: on/off
String cmdTrafficMode   = "auto";
String cmdTrafficSignal = "none";
String cmdParkMode      = "auto";
bool   cmdParkZoneA     = false;
bool   cmdParkZoneB     = false;
bool   cmdBin1Collected = false;
bool   cmdBin2Collected = false;

// ═══════════════════════════════════════════════════
//  SENSOR STATE — ESP sensors
// ═══════════════════════════════════════════════════
float    flowRate     = 0.0f;
float    totalLiters  = 0.0f;
uint32_t lastFlowCalc = 0;
uint32_t lowFlowStart = 0;
bool     leakDetected = false;
String   waterStatus  = "idle";
volatile uint32_t pulseCount = 0;

float temperature = 0.0f;
float humidity    = 0.0f;
bool  dhtReady    = false;

int      ldrRaw       = 0;
bool     isDark       = false;
bool     motionActive = false;
bool     lightsOn     = false;
String   streetMode   = "auto";
bool     pirWarmedUp  = false;
uint32_t lastMotion   = 0;

// ═══════════════════════════════════════════════════
//  SENSOR STATE — Arduino (via Serial, future)
// ═══════════════════════════════════════════════════
int    parkZoneA       = 0;
int    parkZoneB       = 0;
String parkZoneAStatus = "ok";
String parkZoneBStatus = "ok";
bool   pumpA           = false;
bool   pumpB           = false;
String parkMode        = "auto";

long   trafficCountA  = 0;
long   trafficPerMin  = 0;
long   trafficCountB  = 0;
long   trafficPerMinB = 0;
String trafficSignal  = "green_a";
long   signalDurSec   = 20;
String laneAStatus    = "clear";
String laneBStatus    = "clear";

int    bin1Level  = 0;
int    bin2Level  = 0;
String bin1Status = "empty";
String bin2Status = "empty";
bool   wasteAlert = false;

String arSerialBuf = "";
bool   arduinoConnected = false;
uint32_t lastArduinoData = 0;

// ═══════════════════════════════════════════════════
//  TIMERS & FLAGS
// ═══════════════════════════════════════════════════
uint32_t lastDHTRead     = 0;
uint32_t lastStreetRead  = 0;
uint32_t lastFirebase    = 0;
uint32_t lastArCmd       = 0;
uint32_t lastHeartbeat   = 0;
uint32_t lastStatusPrint = 0;
uint32_t lastWiFiRetry   = 0;
uint32_t lastCmdPoll     = 0;
uint32_t bootTime        = 0;

bool wifiOK     = false;
bool firebaseOK = false;
bool streamOK   = false;

// ═══════════════════════════════════════════════════
//  ISR
// ═══════════════════════════════════════════════════
ICACHE_RAM_ATTR void onFlowPulse() { pulseCount++; }

// ═══════════════════════════════════════════════════
//  WATER FLOW CALC
// ═══════════════════════════════════════════════════
void calcFlow(uint32_t now) {
  noInterrupts(); uint32_t p = pulseCount; pulseCount = 0; interrupts();
  float sec = FLOW_CALC_MS / 1000.0f;
  flowRate = (p / sec / FLOW_CALIBRATION) * 60.0f;
  if (flowRate > 0.1f) totalLiters += flowRate * (FLOW_CALC_MS / 60000.0f);

  if      (flowRate >= FLOW_CRITICAL_THRESH) waterStatus = "critical";
  else if (flowRate >= FLOW_HIGH_THRESH)     { waterStatus = "high"; lowFlowStart = 0; }
  else if (flowRate > 0.05f && flowRate < FLOW_LEAK_THRESH) {
    if (!lowFlowStart) lowFlowStart = now;
    if (now - lowFlowStart >= LEAK_TIME_MS) { leakDetected = true; waterStatus = "leak"; }
    else waterStatus = "low_flow";
  } else if (flowRate >= FLOW_NORMAL_MIN) {
    waterStatus = "normal"; leakDetected = false; lowFlowStart = 0;
  } else waterStatus = "idle";
}

// ═══════════════════════════════════════════════════
//  DHT22 — quiet read, no scattered prints
// ═══════════════════════════════════════════════════
void readDHT22() {
  float h = dht.readHumidity();
  float t = dht.readTemperature();
  if (isnan(h) || isnan(t) || h < 0 || h > 100 || t < -40 || t > 80) {
    dhtReady = false; return;
  }
  temperature = t; humidity = h; dhtReady = true;
}

float calcFeelsLike(float t, float h) {
  if (t >= 27.0f) return -8.784695f + 1.61139411f*t + 2.338549f*h
    - 0.14611605f*t*h - 0.01230809f*t*t - 0.01642482f*h*h;
  return t;
}
float calcDewPoint(float t, float h) {
  float a = 17.271f, b = 237.7f, g = (a*t/(b+t)) + log(h/100.0f);
  return (b*g) / (a-g);
}

// ═══════════════════════════════════════════════════
//  STREET LIGHTS
//
//  AUTO LOGIC (simple):
//    Day (sunlight)              → Light OFF
//    Night + Motion detected     → Light ON
//    Night + No motion           → Light OFF
//
//  ⚠️ IMPORTANT — LDR module ka behavior check karo:
//    Kuch modules roshni mein HIGH dete hain (normal)
//    Kuch modules roshni mein LOW dete hain (inverted)
//
//  Agar light ulta kaam kar rahi ho (day mein ON, night mein OFF)
//  to neeche 'LDR_INVERTED' ki value badal do (true <-> false)
// ═══════════════════════════════════════════════════
#define LDR_INVERTED   true    // ← Agar ulta kaam ho, yeh 'false' karo

void readStreet(uint32_t now) {
  int ldrDigital = digitalRead(LDR_PIN);

  // Determine isDark based on module type
  if (LDR_INVERTED) {
    // Inverted module: roshni mein LOW, dark mein HIGH
    isDark = (ldrDigital == HIGH);
  } else {
    // Normal module: roshni mein HIGH, dark mein LOW
    isDark = (ldrDigital == LOW);
  }
  ldrRaw = isDark ? 100 : 1000;   // for website display

  // PIR motion detection
  if (pirWarmedUp) {
    if (digitalRead(PIR_PIN)) {
      motionActive = true;
      lastMotion   = now;
    } else if (now - lastMotion >= MOTION_HOLD_MS) {
      motionActive = false;
    }
  }

  streetMode = cmdStreetMode;

  // ── ZONE A (LIVE — sensor + manual) ──
  // Zone A "global mode" buttons (Force ON / OFF / AUTO) sirf Zone A pe asar karte hain
  // (top wale buttons "All ON / All OFF / All AUTO" alag hain — woh sab zones broadcast karte hain)
  bool zoneAOn;
  if (cmdStreetMode == "on") {
    zoneAOn = true;                            // Force ON
  } else if (cmdStreetMode == "off") {
    zoneAOn = false;                           // Force OFF
  } else {
    // AUTO mode — sensor logic
    if (!isDark)            zoneAOn = false;   // Day → OFF
    else if (motionActive)  zoneAOn = true;    // Night + Motion → ON
    else                    zoneAOn = false;   // Night + No motion → OFF
  }
  lightsOn = zoneAOn;
  digitalWrite(STREET_PIN, zoneAOn ? HIGH : LOW);

  // ── ZONE B (FULLY INDEPENDENT — apna manual control) ──
  bool zoneBOn;
  if (cmdZoneBMode == "on") {
    zoneBOn = true;                            // Manual ON
  } else if (cmdZoneBMode == "off") {
    zoneBOn = false;                           // Manual OFF
  } else {
    // AUTO — apna sensor logic (Zone A jaisa)
    if (!isDark)            zoneBOn = false;
    else if (motionActive)  zoneBOn = true;
    else                    zoneBOn = false;
  }
  digitalWrite(ZONE_B_PIN, zoneBOn ? HIGH : LOW);

  // ── ZONE C (FULLY INDEPENDENT — apna manual control) ──
  bool zoneCOn;
  if (cmdZoneCMode == "on") {
    zoneCOn = true;                            // Manual ON
  } else if (cmdZoneCMode == "off") {
    zoneCOn = false;                           // Manual OFF
  } else {
    // AUTO — apna sensor logic
    if (!isDark)            zoneCOn = false;
    else if (motionActive)  zoneCOn = true;
    else                    zoneCOn = false;
  }
  digitalWrite(ZONE_C_PIN, zoneCOn ? HIGH : LOW);
}

// ═══════════════════════════════════════════════════
//  ARDUINO SERIAL — parse data
// ═══════════════════════════════════════════════════
void parseArduinoData(String& line) {
  if (line.startsWith("DATA:")) line = line.substring(5);
  if (!line.startsWith("{")) return;

  auto getInt = [&](const char* key) -> int {
    String k = "\""; k += key; k += "\":";
    int idx = line.indexOf(k); if (idx < 0) return 0;
    idx += k.length();
    return line.substring(idx, line.indexOf(',', idx)).toInt();
  };
  auto getStr = [&](const char* key) -> String {
    String k = "\""; k += key; k += "\":\"";
    int idx = line.indexOf(k); if (idx < 0) return "";
    idx += k.length();
    return line.substring(idx, line.indexOf('"', idx));
  };
  auto getBool = [&](const char* key) -> bool {
    String k = "\""; k += key; k += "\":";
    int idx = line.indexOf(k); if (idx < 0) return false;
    return line.substring(idx + k.length(), idx + k.length() + 4) == "true";
  };

  parkZoneA       = getInt("pa");
  parkZoneB       = getInt("pb");
  parkZoneAStatus = getStr("pas");
  parkZoneBStatus = getStr("pbs");
  pumpA           = getBool("pua");
  pumpB           = getBool("pub");
  parkMode        = getStr("pmd");
  trafficCountA   = getInt("ta");
  trafficPerMin   = getInt("tapm");
  laneAStatus     = getStr("las");
  trafficCountB   = getInt("tb");
  trafficPerMinB  = getInt("tbpm");
  laneBStatus     = getStr("lbs");
  trafficSignal   = getStr("sig");
  signalDurSec    = getInt("sdur");
  bin1Level       = getInt("w1");
  bin2Level       = getInt("w2");
  bin1Status      = getStr("w1s");
  bin2Status      = getStr("w2s");
  wasteAlert      = getBool("wa");

  arduinoConnected = true;
  lastArduinoData  = millis();
}

void readArduinoSerial() {
  while (arSerial.available()) {
    char c = arSerial.read();
    if (c == '\n') {
      arSerialBuf.trim();
      if (arSerialBuf.length() > 5) parseArduinoData(arSerialBuf);
      arSerialBuf = "";
    } else if (arSerialBuf.length() < 300) {
      arSerialBuf += c;
    }
  }
  if (arduinoConnected && (millis() - lastArduinoData > 15000)) {
    arduinoConnected = false;
  }
}

// ═══════════════════════════════════════════════════
//  SEND COMMANDS TO ARDUINO
// ═══════════════════════════════════════════════════
void sendArduinoCommands() {
  arSerial.print("CMD:PARK_MODE:"); arSerial.println(cmdParkMode);           delay(5);
  arSerial.print("CMD:PUMP_A:");    arSerial.println(cmdParkZoneA ? "1":"0"); delay(5);
  arSerial.print("CMD:PUMP_B:");    arSerial.println(cmdParkZoneB ? "1":"0"); delay(5);
  arSerial.print("CMD:TRAFFIC:");   arSerial.println(cmdTrafficMode);         delay(5);
}

// ═══════════════════════════════════════════════════
//  POLLING BACKUP — every 2 sec, read all commands
//  This is a safety net in case stream fails silently
// ═══════════════════════════════════════════════════
void pollCommands() {
  if (!firebaseOK) return;

  String newStreetMode = cmdStreetMode;
  String newZoneBMode  = cmdZoneBMode;
  String newZoneCMode  = cmdZoneCMode;
  String newTrafficMode = cmdTrafficMode;
  String newTrafficSig = "none";
  String newParkMode = cmdParkMode;
  bool newPumpA = cmdParkZoneA;
  bool newPumpB = cmdParkZoneB;

  if (Firebase.getString(fbData, "/commands/street/mode"))
    newStreetMode = fbData.stringData();
  if (Firebase.getString(fbData, "/commands/street/zone_b"))
    newZoneBMode = fbData.stringData();
  if (Firebase.getString(fbData, "/commands/street/zone_c"))
    newZoneCMode = fbData.stringData();
  if (Firebase.getString(fbData, "/commands/traffic/mode"))
    newTrafficMode = fbData.stringData();
  if (Firebase.getString(fbData, "/commands/traffic/signal")) {
    String s = fbData.stringData();
    if (s.length() > 0 && s != "none") newTrafficSig = s;
  }
  if (Firebase.getString(fbData, "/commands/park/mode"))
    newParkMode = fbData.stringData();
  if (Firebase.getBool(fbData, "/commands/park/zone_a_pump"))
    newPumpA = fbData.boolData();
  if (Firebase.getBool(fbData, "/commands/park/zone_b_pump"))
    newPumpB = fbData.boolData();

  // Detect changes and apply
  if (newStreetMode != cmdStreetMode) {
    Serial.print(F("[CMD] Street GLOBAL mode: "));
    Serial.print(cmdStreetMode); Serial.print(F(" -> ")); Serial.println(newStreetMode);
    cmdStreetMode = newStreetMode;
    // readStreet() applies on next cycle (very fast, 500ms)
  }

  if (newZoneBMode != cmdZoneBMode) {
    Serial.print(F("[CMD] Zone B mode: "));
    Serial.print(cmdZoneBMode); Serial.print(F(" -> ")); Serial.println(newZoneBMode);
    cmdZoneBMode = newZoneBMode;
  }

  if (newZoneCMode != cmdZoneCMode) {
    Serial.print(F("[CMD] Zone C mode: "));
    Serial.print(cmdZoneCMode); Serial.print(F(" -> ")); Serial.println(newZoneCMode);
    cmdZoneCMode = newZoneCMode;
  }

  if (newTrafficMode != cmdTrafficMode) {
    Serial.print(F("[CMD] Traffic mode -> ")); Serial.println(newTrafficMode);
    cmdTrafficMode = newTrafficMode;
    arSerial.print("CMD:TRAFFIC:"); arSerial.println(newTrafficMode);
  }

  if (newTrafficSig != "none") {
    Serial.print(F("[CMD] Traffic signal -> ")); Serial.println(newTrafficSig);
    cmdTrafficSignal = newTrafficSig;
    arSerial.print("CMD:SIGNAL:"); arSerial.println(newTrafficSig);
    Firebase.setString(fbData, "/commands/traffic/signal", "none");
  }

  if (newParkMode != cmdParkMode) {
    Serial.print(F("[CMD] Park mode -> ")); Serial.println(newParkMode);
    cmdParkMode = newParkMode;
    arSerial.print("CMD:PARK_MODE:"); arSerial.println(newParkMode);
  }

  if (newPumpA != cmdParkZoneA) {
    Serial.print(F("[CMD] Pump A -> ")); Serial.println(newPumpA ? "ON" : "OFF");
    cmdParkZoneA = newPumpA;
    arSerial.print("CMD:PUMP_A:"); arSerial.println(newPumpA ? "1":"0");
  }

  if (newPumpB != cmdParkZoneB) {
    Serial.print(F("[CMD] Pump B -> ")); Serial.println(newPumpB ? "ON" : "OFF");
    cmdParkZoneB = newPumpB;
    arSerial.print("CMD:PUMP_B:"); arSerial.println(newPumpB ? "1":"0");
  }

  // Waste collect commands
  if (Firebase.getBool(fbData, "/commands/waste/bin1_collected")) {
    if (fbData.boolData()) {
      Serial.println(F("[CMD] Bin 1 collected"));
      arSerial.println("CMD:BIN1_RST:1");
      bin1Level = 0; bin1Status = "empty";
      Firebase.setBool(fbData, "/commands/waste/bin1_collected", false);
    }
  }
  if (Firebase.getBool(fbData, "/commands/waste/bin2_collected")) {
    if (fbData.boolData()) {
      Serial.println(F("[CMD] Bin 2 collected"));
      arSerial.println("CMD:BIN2_RST:1");
      bin2Level = 0; bin2Status = "empty";
      Firebase.setBool(fbData, "/commands/waste/bin2_collected", false);
    }
  }
}

// ═══════════════════════════════════════════════════
//  FIREBASE STREAM HANDLER — INSTANT manual control
// ═══════════════════════════════════════════════════
void handleStreamData() {
  String path = fbStream.dataPath();
  String val  = fbStream.stringData();

  // Street GLOBAL mode (Force ON / OFF / AUTO)
  if (path.endsWith("/street/mode")) {
    cmdStreetMode = val;
    Serial.println("[STREAM] Street GLOBAL: " + val);
    // readStreet() applies on next cycle
    return;
  }

  // Street Zone B mode (per-zone manual)
  if (path.endsWith("/street/zone_b")) {
    cmdZoneBMode = val;
    Serial.println("[STREAM] Zone B: " + val);
    return;
  }

  // Street Zone C mode (per-zone manual)
  if (path.endsWith("/street/zone_c")) {
    cmdZoneCMode = val;
    Serial.println("[STREAM] Zone C: " + val);
    return;
  }

  // Traffic mode
  if (path.endsWith("/traffic/mode")) {
    cmdTrafficMode = val;
    arSerial.print("CMD:TRAFFIC:"); arSerial.println(val);
    return;
  }

  // Traffic signal (manual override)
  if (path.endsWith("/traffic/signal")) {
    if (val != "none" && val.length() > 0) {
      cmdTrafficSignal = val;
      arSerial.print("CMD:SIGNAL:"); arSerial.println(val);
      // auto-clear
      delay(10);
      Firebase.setString(fbData, "/commands/traffic/signal", "none");
    }
    return;
  }

  // Park mode
  if (path.endsWith("/park/mode")) {
    cmdParkMode = val;
    arSerial.print("CMD:PARK_MODE:"); arSerial.println(val);
    return;
  }

  // Park Pump A
  if (path.endsWith("/park/zone_a_pump")) {
    cmdParkZoneA = (val == "true" || val == "1");
    arSerial.print("CMD:PUMP_A:"); arSerial.println(cmdParkZoneA ? "1":"0");
    return;
  }

  // Park Pump B
  if (path.endsWith("/park/zone_b_pump")) {
    cmdParkZoneB = (val == "true" || val == "1");
    arSerial.print("CMD:PUMP_B:"); arSerial.println(cmdParkZoneB ? "1":"0");
    return;
  }

  // Waste Bin 1 collect
  if (path.endsWith("/waste/bin1_collected")) {
    if (val == "true") {
      cmdBin1Collected = true;
      arSerial.println("CMD:BIN1_RST:1");
      bin1Level = 0; bin1Status = "empty";  // update ESP copy immediately
      Firebase.setBool(fbData, "/commands/waste/bin1_collected", false);
    }
    return;
  }

  // Waste Bin 2 collect
  if (path.endsWith("/waste/bin2_collected")) {
    if (val == "true") {
      cmdBin2Collected = true;
      arSerial.println("CMD:BIN2_RST:1");
      bin2Level = 0; bin2Status = "empty";
      Firebase.setBool(fbData, "/commands/waste/bin2_collected", false);
    }
    return;
  }
}

// ═══════════════════════════════════════════════════
//  FIREBASE SEND
// ═══════════════════════════════════════════════════
void sendWeather() {
  if (!dhtReady) return;
  FirebaseJson j;
  j.set("temperature", temperature);
  j.set("humidity",    humidity);
  j.set("feels_like",  calcFeelsLike(temperature, humidity));
  j.set("heat_index",  dht.computeHeatIndex(temperature, humidity, false));
  j.set("dew_point",   calcDewPoint(temperature, humidity));
  j.set("sensor",      "DHT22");
  j.set("timestamp",   (long)millis());
  Firebase.updateNode(fbData, "/sensors/weather", j);
}

void sendWater() {
  FirebaseJson j;
  j.set("flow_rate",     flowRate);
  j.set("total_liters",  totalLiters);
  j.set("status",        waterStatus);
  j.set("leak_detected", leakDetected);
  j.set("timestamp",     (long)millis());
  Firebase.updateNode(fbData, "/sensors/water", j);
}

void sendStreet() {
  FirebaseJson j;
  j.set("lux_raw",     ldrRaw);
  j.set("is_dark",     isDark);
  j.set("motion",      motionActive);
  j.set("lights_on",   lightsOn);
  j.set("mode",        streetMode);
  // Per-zone live status
  j.set("zone_a_on",   digitalRead(STREET_PIN) == HIGH);
  j.set("zone_b_on",   digitalRead(ZONE_B_PIN) == HIGH);
  j.set("zone_c_on",   digitalRead(ZONE_C_PIN) == HIGH);
  j.set("zone_b_mode", cmdZoneBMode);
  j.set("zone_c_mode", cmdZoneCMode);
  j.set("timestamp",   (long)millis());
  Firebase.updateNode(fbData, "/sensors/street", j);
}

void sendTraffic() {
  FirebaseJson j;
  j.set("lane_a_count",        trafficCountA);
  j.set("lane_a_per_min",      trafficPerMin);
  j.set("lane_a_status",       laneAStatus);
  j.set("lane_b_count",        trafficCountB);
  j.set("lane_b_per_min",      trafficPerMinB);
  j.set("lane_b_status",       laneBStatus);
  j.set("total_vehicles",      trafficCountA + trafficCountB);
  j.set("signal",              trafficSignal);
  j.set("signal_duration_sec", signalDurSec);
  j.set("mode",                cmdTrafficMode);
  j.set("timestamp",           (long)millis());
  Firebase.updateNode(fbData, "/sensors/traffic", j);
}

void sendWaste() {
  FirebaseJson j;
  j.set("bin1_level",  bin1Level);
  j.set("bin1_status", bin1Status);
  j.set("bin2_level",  bin2Level);
  j.set("bin2_status", bin2Status);
  j.set("alert",       wasteAlert);
  j.set("timestamp",   (long)millis());
  Firebase.updateNode(fbData, "/sensors/waste", j);
}

void sendPark() {
  FirebaseJson j;
  j.set("zone_a",        parkZoneA);
  j.set("zone_b",        parkZoneB);
  j.set("zone_a_status", parkZoneAStatus);
  j.set("zone_b_status", parkZoneBStatus);
  j.set("pump_a",        pumpA);
  j.set("pump_b",        pumpB);
  j.set("mode",          parkMode);
  j.set("timestamp",     (long)millis());
  Firebase.updateNode(fbData, "/sensors/park", j);
}

void sendAll() {
  if (!firebaseOK) { firebaseOK = Firebase.ready(); return; }
  sendWeather();
  sendWater();
  sendStreet();
  sendTraffic();
  sendWaste();
  sendPark();
}

// ═══════════════════════════════════════════════════
//  CLEAN STATUS PRINT — box format, har 5 sec
// ═══════════════════════════════════════════════════
void printStatus() {
  Serial.println();
  Serial.println(F("+-----------------------------------------+"));
  Serial.println(F("|     SMART CITY STATUS  v7.0            |"));
  Serial.println(F("+-----------------------------------------+"));

  // System
  Serial.print(F("| WiFi      : "));
  if (wifiOK) { Serial.print(F("OK  ")); Serial.println(WiFi.localIP()); }
  else        Serial.println(F("DISCONNECTED"));

  Serial.print(F("| Firebase  : "));
  Serial.println(firebaseOK ? F("CONNECTED") : F("OFFLINE"));

  Serial.print(F("| Stream    : "));
  Serial.println(streamOK ? F("ACTIVE (instant control)") : F("NOT READY"));

  Serial.print(F("| Arduino   : "));
  Serial.println(arduinoConnected ? F("DATA RECEIVING") : F("NOT CONNECTED"));

  Serial.print(F("| Uptime    : "));
  Serial.print(millis() / 60000);
  Serial.println(F(" minutes"));

  // Weather
  Serial.println(F("+--- WEATHER -----------------------------+"));
  if (dhtReady) {
    Serial.print(F("| Temperature : "));
    Serial.print(temperature, 1); Serial.println(F(" C"));
    Serial.print(F("| Humidity    : "));
    Serial.print(humidity, 1);    Serial.println(F(" %"));
  } else {
    Serial.println(F("| DHT22 sensor not ready"));
  }

  // Water
  Serial.println(F("+--- WATER FLOW --------------------------+"));
  Serial.print(F("| Flow rate   : "));
  Serial.print(flowRate, 2); Serial.println(F(" L/min"));
  Serial.print(F("| Total used  : "));
  Serial.print(totalLiters, 1); Serial.println(F(" L"));
  Serial.print(F("| Status      : "));
  Serial.println(waterStatus);
  if (leakDetected) Serial.println(F("| LEAK ALERT  : YES"));

  // Street
  Serial.println(F("+--- STREET LIGHTS -----------------------+"));
  Serial.print(F("| Global Mode : "));
  Serial.println(streetMode);
  Serial.print(F("| LDR value   : "));
  Serial.print(ldrRaw);
  Serial.println(isDark ? F("  (NIGHT)") : F("  (DAY)"));
  Serial.print(F("| Motion      : "));
  Serial.println(motionActive ? F("DETECTED") : F("none"));
  Serial.print(F("| Zone A (D5) : "));
  Serial.print(digitalRead(STREET_PIN) ? F("ON ") : F("OFF"));
  Serial.println(F("  [LIVE]"));
  Serial.print(F("| Zone B (D0) : "));
  Serial.print(digitalRead(ZONE_B_PIN) ? F("ON ") : F("OFF"));
  Serial.print(F("  [mode: "));
  Serial.print(cmdZoneBMode);
  Serial.println(F("]"));
  Serial.print(F("| Zone C (D6) : "));
  Serial.print(digitalRead(ZONE_C_PIN) ? F("ON ") : F("OFF"));
  Serial.print(F("  [mode: "));
  Serial.print(cmdZoneCMode);
  Serial.println(F("]"));

  // Arduino modules (if connected)
  Serial.println(F("+--- TRAFFIC (Arduino) -------------------+"));
  if (arduinoConnected) {
    Serial.print(F("| Lane A      : "));
    Serial.print(trafficCountA); Serial.print(F(" ("));
    Serial.print(trafficPerMin); Serial.print(F("/min) "));
    Serial.println(laneAStatus);
    Serial.print(F("| Lane B      : "));
    Serial.print(trafficCountB); Serial.print(F(" ("));
    Serial.print(trafficPerMinB); Serial.print(F("/min) "));
    Serial.println(laneBStatus);
    Serial.print(F("| Signal      : ")); Serial.println(trafficSignal);
    Serial.print(F("| Mode        : ")); Serial.println(cmdTrafficMode);
  } else {
    Serial.println(F("| Waiting for Arduino data..."));
  }

  Serial.println(F("+--- WASTE BINS (Arduino) ----------------+"));
  if (arduinoConnected) {
    Serial.print(F("| Bin 1       : "));
    Serial.print(bin1Level); Serial.print(F("%  ("));
    Serial.print(bin1Status); Serial.println(F(")"));
    Serial.print(F("| Bin 2       : "));
    Serial.print(bin2Level); Serial.print(F("%  ("));
    Serial.print(bin2Status); Serial.println(F(")"));
    if (wasteAlert) Serial.println(F("| ALERT       : BIN FULL!"));
  } else {
    Serial.println(F("| Waiting for Arduino data..."));
  }

  Serial.println(F("+--- PARK WATERING (Arduino) -------------+"));
  if (arduinoConnected) {
    Serial.print(F("| Zone A      : "));
    Serial.print(parkZoneA); Serial.print(F("%  ("));
    Serial.print(parkZoneAStatus); Serial.println(F(")"));
    Serial.print(F("| Zone B      : "));
    Serial.print(parkZoneB); Serial.print(F("%  ("));
    Serial.print(parkZoneBStatus); Serial.println(F(")"));
    Serial.print(F("| Pump A      : ")); Serial.println(pumpA ? F("ON") : F("OFF"));
    Serial.print(F("| Pump B      : ")); Serial.println(pumpB ? F("ON") : F("OFF"));
    Serial.print(F("| Mode        : ")); Serial.println(cmdParkMode);
  } else {
    Serial.println(F("| Waiting for Arduino data..."));
  }

  Serial.println(F("+-----------------------------------------+"));
  Serial.println(F("Commands:  s = status  r = reset WiFi"));
  Serial.println();
}

// ═══════════════════════════════════════════════════
//  START STREAM
// ═══════════════════════════════════════════════════
void startStream() {
  if (!firebaseOK) return;
  if (!Firebase.beginStream(fbStream, "/commands")) {
    streamOK = false;
    return;
  }
  streamOK = true;
}

// ═══════════════════════════════════════════════════
//  WIFI + FIREBASE
// ═══════════════════════════════════════════════════
void connectWiFi() {
  wifiManager.setConfigPortalTimeout(AP_TIMEOUT);
  wifiManager.setDebugOutput(false);
  wifiManager.setTitle("Smart City WiFi Setup");
  bool ok = wifiManager.autoConnect(AP_SSID, NULL);
  if (ok) wifiOK = true;
  else ESP.restart();
}

void connectFirebase() {
  fbConfig.host = FIREBASE_HOST;
  fbConfig.signer.tokens.legacy_token = FIREBASE_AUTH;
  Firebase.begin(&fbConfig, &fbAuth);
  Firebase.reconnectWiFi(true);
  delay(1000);
  firebaseOK = Firebase.ready();
  if (firebaseOK) {
    Firebase.setString(fbData, "/system/status",   "online");
    Firebase.setString(fbData, "/system/firmware",  "v7.0");
    Firebase.setString(fbData, "/system/wifi",      WiFi.SSID());

    // Initialize commands if first boot
    if (!Firebase.getString(fbData, "/commands/street/mode")) {
      Firebase.setString(fbData, "/commands/street/mode",   "auto");
      Firebase.setString(fbData, "/commands/street/zone_b", "auto");
      Firebase.setString(fbData, "/commands/street/zone_c", "auto");
    }
    if (!Firebase.getString(fbData, "/commands/traffic/mode")) {
      Firebase.setString(fbData, "/commands/traffic/mode",   "auto");
      Firebase.setString(fbData, "/commands/traffic/signal", "none");
    }
    if (!Firebase.getString(fbData, "/commands/park/mode")) {
      Firebase.setString(fbData, "/commands/park/mode",        "auto");
      Firebase.setBool  (fbData, "/commands/park/zone_a_pump", false);
      Firebase.setBool  (fbData, "/commands/park/zone_b_pump", false);
    }
    if (!Firebase.getBool(fbData, "/commands/waste/bin1_collected")) {
      Firebase.setBool(fbData, "/commands/waste/bin1_collected", false);
      Firebase.setBool(fbData, "/commands/waste/bin2_collected", false);
    }

    // Load current command values
    if (Firebase.getString(fbData, "/commands/street/mode"))    cmdStreetMode  = fbData.stringData();
    if (Firebase.getString(fbData, "/commands/street/zone_b"))  cmdZoneBMode   = fbData.stringData();
    if (Firebase.getString(fbData, "/commands/street/zone_c"))  cmdZoneCMode   = fbData.stringData();
    if (Firebase.getString(fbData, "/commands/traffic/mode"))   cmdTrafficMode = fbData.stringData();
    if (Firebase.getString(fbData, "/commands/park/mode"))      cmdParkMode    = fbData.stringData();
    if (Firebase.getBool(fbData,   "/commands/park/zone_a_pump")) cmdParkZoneA = fbData.boolData();
    if (Firebase.getBool(fbData,   "/commands/park/zone_b_pump")) cmdParkZoneB = fbData.boolData();

    startStream();
  }
}

// ═══════════════════════════════════════════════════
//  SETUP
// ═══════════════════════════════════════════════════
void setup() {
  Serial.begin(115200);
  arSerial.begin(9600);
  delay(200);

  Serial.println();
  Serial.println(F("+=========================================+"));
  Serial.println(F("|  SMART CITY ESP8266 v7.0                |"));
  Serial.println(F("|  Starting up...                         |"));
  Serial.println(F("+=========================================+"));

  pinMode(FLOW_PIN,   INPUT_PULLUP);
  pinMode(PIR_PIN,    INPUT);
  pinMode(LDR_PIN,    INPUT);
  pinMode(STREET_PIN, OUTPUT);
  pinMode(ZONE_B_PIN, OUTPUT);
  pinMode(ZONE_C_PIN, OUTPUT);
  digitalWrite(STREET_PIN, LOW);
  digitalWrite(ZONE_B_PIN, LOW);
  digitalWrite(ZONE_C_PIN, LOW);

  dht.begin();
  delay(2000);
  readDHT22();

  attachInterrupt(digitalPinToInterrupt(FLOW_PIN), onFlowPulse, FALLING);

  connectWiFi();
  if (wifiOK) connectFirebase();

  bootTime        = millis();
  lastDHTRead     = millis();
  lastStreetRead  = millis();
  lastFirebase    = millis();
  lastArCmd       = millis();
  lastHeartbeat   = millis();
  lastCmdPoll     = millis();
  lastStatusPrint = millis() - STATUS_PRINT_MS;  // print immediately
  lastFlowCalc    = millis();
}

// ═══════════════════════════════════════════════════
//  MAIN LOOP
// ═══════════════════════════════════════════════════
void loop() {
  uint32_t now = millis();

  // WiFi watchdog
  if (WiFi.status() != WL_CONNECTED) {
    wifiOK = firebaseOK = streamOK = false;
    if (now - lastWiFiRetry >= WIFI_RETRY_MS) {
      WiFi.reconnect();
      lastWiFiRetry = now;
    }
  } else {
    wifiOK = true;
    if (firebaseOK && !streamOK) startStream();
  }

  // PIR warmup
  if (!pirWarmedUp && (now - bootTime >= PIR_WARMUP_MS)) {
    pirWarmedUp = true;
  }

  // 1. Firebase stream — INSTANT command handler
  if (firebaseOK && streamOK) {
    if (!Firebase.readStream(fbStream)) {
      streamOK = false;
    } else if (fbStream.streamTimeout()) {
      streamOK = false;
    } else if (fbStream.streamAvailable()) {
      handleStreamData();
    }
  }

  // 1b. BACKUP — Poll commands every 2 sec (in case stream fails)
  if (now - lastCmdPoll >= CMD_POLL_MS) {
    pollCommands();
    lastCmdPoll = now;
  }

  // 2. Water flow
  if (now - lastFlowCalc >= FLOW_CALC_MS) {
    calcFlow(now); lastFlowCalc = now;
  }

  // 3. DHT22
  if (now - lastDHTRead >= DHT_READ_MS) {
    readDHT22(); lastDHTRead = now;
  }

  // 4. Street lights
  if (now - lastStreetRead >= STREET_READ_MS) {
    readStreet(now); lastStreetRead = now;
  }

  // 5. Arduino serial (continuous)
  readArduinoSerial();

  // 6. Send Arduino commands (backup to stream)
  if (now - lastArCmd >= AR_CMD_MS) {
    sendArduinoCommands(); lastArCmd = now;
  }

  // 7. Firebase upload
  if (now - lastFirebase >= FIREBASE_MS) {
    sendAll(); lastFirebase = now;
  }

  // 8. Heartbeat
  if (now - lastHeartbeat >= HEARTBEAT_MS) {
    if (firebaseOK) {
      Firebase.setInt(fbData, "/system/last_seen", (long)millis());
    }
    lastHeartbeat = now;
  }

  // 9. Status print — THE ONLY PRINT
  if (now - lastStatusPrint >= STATUS_PRINT_MS) {
    printStatus();
    lastStatusPrint = now;
  }

  // 10. Serial commands
  if (Serial.available()) {
    char c = Serial.read();
    if (c == 'r' || c == 'R') {
      wifiManager.resetSettings();
      delay(500);
      ESP.restart();
    }
    if (c == 's' || c == 'S') {
      printStatus();
    }
  }

  delay(5);
}
