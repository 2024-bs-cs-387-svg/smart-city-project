/*
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║   SMART CITY — Arduino UNO  v3.1                                 ║
 * ║                                                                  ║
 * ║   Arduino handles (ALL 5V sensors — no voltage dividers!):       ║
 * ║    ✅ HC-SR04 × 4  — Traffic 2 lanes + 2 bins                    ║
 * ║        Shared TRIG pin 2, separate ECHO pins                     ║
 * ║    ✅ Traffic LED INT-A  → Red:4  Yellow:5  Green:6              ║
 * ║    ✅ Traffic LED INT-B  → Red:7  Yellow:8  Green:A2             ║
 * ║    ✅ Soil × 2   → Park Zones A:A0  B:A1                         ║
 * ║    ✅ Relay × 2  → Park Pumps   A:9  B:10                        ║
 * ║    ✅ Serial     → ESP8266      TX:11  RX:12                     ║
 * ║                                                                  ║
 * ║   4 HC-SR04 Setup (shared TRIG trick):                           ║
 * ║    TRIG (shared)      → Pin 2  (connects to ALL 4 sensors)       ║
 * ║    Lane A ECHO        → Pin 3                                    ║
 * ║    Lane B ECHO        → Pin 13                                   ║
 * ║    Bin 1 ECHO         → A4                                       ║
 * ║    Bin 2 ECHO         → A5                                       ║
 * ║                                                                  ║
 * ║   Traffic Signal FSM:                                            ║
 * ║    GREEN_A → YELLOW_A → GREEN_B → YELLOW_B → (repeat)           ║
 * ║    Auto timing = density-based from BOTH lane sensors            ║
 * ║    Manual override = from ESP command instantly                  ║
 * ║                                                                  ║
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 * ════════════════════════════════════════════════════════════════════
 *  ARDUINO UNO PIN WIRING — 4 HC-SR04 sensors
 * ════════════════════════════════════════════════════════════════════
 *
 *  SHARED TRIG PIN (connects to all 4 HC-SR04):
 *    Arduino Pin 2 → 4 branch wires → TRIG pin of each sensor
 *    Agar breadboard hai to Pin 2 ki 1 wire ek row pe lagao,
 *    us row se 4 wires nikal ke har sensor ke TRIG pe le jao
 *
 *  HC-SR04 #1 — Traffic Lane A:
 *    VCC  → 5V  |  GND → GND
 *    TRIG → Pin 2 (shared)
 *    ECHO → Pin 3
 *
 *  HC-SR04 #2 — Traffic Lane B:
 *    VCC  → 5V  |  GND → GND
 *    TRIG → Pin 2 (shared)
 *    ECHO → Pin 13
 *
 *  HC-SR04 #3 — Waste Bin 1:
 *    VCC  → 5V  |  GND → GND
 *    TRIG → Pin 2 (shared)
 *    ECHO → A4
 *
 *  HC-SR04 #4 — Waste Bin 2:
 *    VCC  → 5V  |  GND → GND
 *    TRIG → Pin 2 (shared)
 *    ECHO → A5
 *
 *  Traffic Light LEDs — Intersection A (Lane A):
 *    Pin 4 → [1kΩ] → Red LED (+) → LED (-) → GND
 *    Pin 5 → [1kΩ] → Yellow LED (+) → LED (-) → GND
 *    Pin 6 → [1kΩ] → Green LED (+) → LED (-) → GND
 *
 *  Traffic Light LEDs — Intersection B (Lane B):
 *    Pin 7 → [1kΩ] → Red LED B → GND
 *    Pin 8 → [1kΩ] → Yellow LED B → GND
 *    A2    → [1kΩ] → Green LED B → GND
 *
 *  Soil Sensor Zone A:  VCC→5V  GND→GND  AO→A0  (DO not used)
 *  Soil Sensor Zone B:  VCC→5V  GND→GND  AO→A1  (DO not used)
 *
 *  Relay Pump A: VCC→5V  GND→GND  IN→Pin 9
 *  Relay Pump B: VCC→5V  GND→GND  IN→Pin 10
 *
 *  Serial to ESP8266:
 *    Pin 11 (TX) → [1kΩ → ESP D8 → 2kΩ → GND]  ← voltage divider!
 *    Pin 12 (RX) ← ESP D7 (direct, 3.3V safe for Arduino input)
 *    Arduino GND ←→ ESP GND  (zaruri!)
 *
 * ════════════════════════════════════════════════════════════════════
 *  ⚠️  UPLOAD NOTE:
 *    Pin 11 (TX to ESP) disconnect karo pehle, upload karo, phir reconnect
 * ════════════════════════════════════════════════════════════════════
 */

#include <SoftwareSerial.h>

// ════════════════════════════════════════════════
//  SoftwareSerial: RX=Pin12, TX=Pin11
// ════════════════════════════════════════════════
SoftwareSerial espSerial(12, 11);  // RX=12 (from ESP), TX=11 (to ESP)

// ════════════════════════════════════════════════
//  SHARED TRIG PIN — saari 4 HC-SR04 ka trigger ek hi pin se
//  Yeh trick 4 ECHO pins bachati hai
// ════════════════════════════════════════════════
#define TRIG_SHARED   2   // Ek hi TRIG pin sab 4 HC-SR04 ke liye

// ════════════════════════════════════════════════
//  TRAFFIC PINS — 2 HC-SR04 sensors
// ════════════════════════════════════════════════
#define ECHO_LANE_A   3   // Lane A HC-SR04 ECHO
#define ECHO_LANE_B  13   // Lane B HC-SR04 ECHO

// INT-A LEDs (Lane A)
#define LED_A_RED     4
#define LED_A_YEL     5
#define LED_A_GRN     6
// INT-B LEDs (Lane B)
#define LED_B_RED     7
#define LED_B_YEL     8
#define LED_B_GRN    A2   // analog pin used as digital output

// ════════════════════════════════════════════════
//  WASTE PINS — 2 HC-SR04 sensors
// ════════════════════════════════════════════════
#define ECHO_BIN1    A4   // Bin 1 ECHO
#define ECHO_BIN2    A5   // Bin 2 ECHO

// ════════════════════════════════════════════════
//  PARK PINS
// ════════════════════════════════════════════════
#define SOIL_A       A0
#define SOIL_B       A1
#define RELAY_A       9   // Pump A (or LED for testing)
#define RELAY_B      10   // Pump B (or LED for testing)

// ════════════════════════════════════════════════
//  RELAY LOGIC — change based on what's connected:
//
//  • TRUE  → Real relay module (most cheap modules are active LOW)
//            HIGH = pump OFF, LOW = pump ON
//
//  • FALSE → LED for testing (jab relay available nahi)
//            HIGH = LED ON, LOW = LED OFF
//            (LED anode → Arduino pin via 1kΩ, cathode → GND)
// ════════════════════════════════════════════════
#define RELAY_ACTIVE_LOW false   // ← FALSE for LED testing (change to true when relay arrives)

// ════════════════════════════════════════════════
//  CALIBRATION
// ════════════════════════════════════════════════
// Soil sensor:
#define SOIL_DRY    850   // raw value when dry
#define SOIL_WET    250   // raw value when wet
// Park auto:
#define AUTO_ON_PCT  30   // below this = pump ON
#define AUTO_OFF_PCT 75   // above this = pump OFF
// Waste bin:
#define BIN_HEIGHT_CM  50.0f   // ← Apni bin ki andar ki height (cm) daalo
#define BIN_FULL      80.0f
#define BIN_OK        40.0f
// Traffic:
#define VEHICLE_DIST_CM  150   // below this distance = vehicle detected
#define VEHICLE_COOLDOWN 2000  // ms between vehicle counts

// ════════════════════════════════════════════════
//  TRAFFIC SIGNAL FSM
// ════════════════════════════════════════════════
enum SignalState { GREEN_A, YELLOW_A, GREEN_B, YELLOW_B, RED_ALL };
SignalState sigState = GREEN_A;

#define SIG_YELLOW_MS  3000    // Yellow phase = 3 seconds
#define SIG_MIN_MS    15000    // Min green = 15 sec
#define SIG_MAX_MS    60000    // Max green = 60 sec
#define SIG_BASE_MS   20000    // Default green = 20 sec

uint32_t sigTimer       = 0;
uint32_t sigDuration    = SIG_BASE_MS;
String   trafficMode    = "auto";    // "auto" | "manual"
String   manualCmd      = "none";    // command from ESP

// ════════════════════════════════════════════════
//  STATE VARIABLES
// ════════════════════════════════════════════════
// Traffic — Lane A
long     vehicleCountA   = 0;
long     vehiclePerMinA  = 0;
bool     vehicleInA      = false;
uint32_t lastCooldownA   = 0;
String   laneAStatus     = "clear";

// Traffic — Lane B
long     vehicleCountB   = 0;
long     vehiclePerMinB  = 0;
bool     vehicleInB      = false;
uint32_t lastCooldownB   = 0;
String   laneBStatus     = "clear";

uint32_t lastMinReset    = 0;

// Waste — both bins LIVE now
float  bin1Level   = 0.0f;
float  bin2Level   = 0.0f;
String bin1Status  = "empty";
String bin2Status  = "empty";
bool   wasteAlert  = false;

// Park
int    soilA    = 0;
int    soilB    = 0;
bool   pumpAon  = false;
bool   pumpBon  = false;
String parkMode = "auto";

// Commands from ESP
bool   cmdBin1Reset = false;
bool   cmdBin2Reset = false;

// Serial buffer
String espBuf = "";

// Timers
uint32_t lastTrafficRead = 0;
uint32_t lastWasteRead   = 0;
uint32_t lastSoilRead    = 0;
uint32_t lastSend        = 0;

// ════════════════════════════════════════════════
//  RELAY CONTROL
// ════════════════════════════════════════════════
void setPump(int pin, bool on) {
  digitalWrite(pin, RELAY_ACTIVE_LOW ? (on ? LOW : HIGH) : (on ? HIGH : LOW));
}

// ════════════════════════════════════════════════
//  ULTRASONIC (5V — no voltage divider needed!)
// ════════════════════════════════════════════════
float readUltrasonic(int trig, int echo) {
  digitalWrite(trig, LOW);  delayMicroseconds(2);
  digitalWrite(trig, HIGH); delayMicroseconds(10);
  digitalWrite(trig, LOW);
  long dur = pulseIn(echo, HIGH, 25000);
  if (dur == 0) return -1;
  return dur * 0.034f / 2.0f;
}

// ════════════════════════════════════════════════
//  SOIL SENSOR
// ════════════════════════════════════════════════
int readSoil(int pin) {
  long sum = 0;
  for (int i = 0; i < 5; i++) { sum += analogRead(pin); delay(5); }
  return constrain(map(sum/5, SOIL_DRY, SOIL_WET, 0, 100), 0, 100);
}

String soilStatus(int pct) {
  if (pct < AUTO_ON_PCT)  return "dry";
  if (pct > AUTO_OFF_PCT) return "wet";
  return "ok";
}

// ════════════════════════════════════════════════
//  TRAFFIC SIGNAL LEDs
// ════════════════════════════════════════════════
void setSignalLEDs(SignalState s) {
  // INT-A
  digitalWrite(LED_A_RED, (s == RED_ALL || s == GREEN_B || s == YELLOW_B || s == YELLOW_A) ? HIGH : LOW);
  digitalWrite(LED_A_YEL, (s == YELLOW_A) ? HIGH : LOW);
  digitalWrite(LED_A_GRN, (s == GREEN_A)  ? HIGH : LOW);
  // INT-B
  digitalWrite(LED_B_RED, (s == RED_ALL || s == GREEN_A || s == YELLOW_A || s == YELLOW_B) ? HIGH : LOW);
  digitalWrite(LED_B_YEL, (s == YELLOW_B) ? HIGH : LOW);
  digitalWrite(LED_B_GRN, (s == GREEN_B)  ? HIGH : LOW);
}

String signalStateName(SignalState s) {
  switch(s) {
    case GREEN_A:  return "green_a";
    case YELLOW_A: return "yellow_a";
    case GREEN_B:  return "green_b";
    case YELLOW_B: return "yellow_b";
    case RED_ALL:  return "red_all";
    default:       return "unknown";
  }
}

long calcGreenADuration() {
  // Lane A green duration based on Lane A density
  long ms = SIG_BASE_MS + (vehiclePerMinA * 2000L);
  return constrain(ms, (long)SIG_MIN_MS, (long)SIG_MAX_MS);
}

long calcGreenBDuration() {
  // Lane B green duration based on Lane B density
  long ms = SIG_BASE_MS + (vehiclePerMinB * 2000L);
  return constrain(ms, (long)SIG_MIN_MS, (long)SIG_MAX_MS);
}

// ════════════════════════════════════════════════
//  TRAFFIC SIGNAL FSM UPDATE
// ════════════════════════════════════════════════
void updateSignalFSM(uint32_t now) {

  // ── Manual override from ESP ──
  if (trafficMode == "manual" && manualCmd != "none") {
    if      (manualCmd == "green_a")     { sigState = GREEN_A;  sigTimer = now; sigDuration = SIG_BASE_MS; }
    else if (manualCmd == "green_b")     { sigState = GREEN_B;  sigTimer = now; sigDuration = SIG_BASE_MS; }
    else if (manualCmd == "red_all")     { sigState = RED_ALL;  sigTimer = now; sigDuration = 600000UL; }
    else if (manualCmd == "emergency_a") { sigState = GREEN_A;  sigTimer = now; sigDuration = 300000UL; }
    else if (manualCmd == "emergency_b") { sigState = GREEN_B;  sigTimer = now; sigDuration = 300000UL; }
    setSignalLEDs(sigState);
    manualCmd = "none";
    return;
  }

  if (trafficMode == "manual") return;  // stay in current state

  // ── Auto FSM (density-based for BOTH lanes) ──
  uint32_t elapsed = now - sigTimer;
  if (elapsed < sigDuration) return;

  switch (sigState) {
    case GREEN_A:
      sigState = YELLOW_A;
      sigDuration = SIG_YELLOW_MS;
      break;
    case YELLOW_A:
      sigState = GREEN_B;
      sigDuration = calcGreenBDuration();   // density-based
      Serial.print(F("[Signal] -> GREEN_B  dur:"));
      Serial.print(sigDuration/1000);
      Serial.print(F("s  density:"));
      Serial.print(vehiclePerMinB);
      Serial.println(F("/min"));
      break;
    case GREEN_B:
      sigState = YELLOW_B;
      sigDuration = SIG_YELLOW_MS;
      break;
    case YELLOW_B:
      sigState = GREEN_A;
      sigDuration = calcGreenADuration();
      Serial.print(F("[Signal] -> GREEN_A  dur:"));
      Serial.print(sigDuration/1000);
      Serial.print(F("s  density:"));
      Serial.print(vehiclePerMinA);
      Serial.println(F("/min"));
      break;
    case RED_ALL:
      return;
  }

  sigTimer = now;
  setSignalLEDs(sigState);
}

// ════════════════════════════════════════════════
//  READ TRAFFIC SENSOR — Lane A + Lane B
// ════════════════════════════════════════════════
void readTrafficSensor(uint32_t now) {
  // Lane A — read with shared TRIG + ECHO_LANE_A
  float distA = readUltrasonic(TRIG_SHARED, ECHO_LANE_A);
  if (distA > 0 && distA < VEHICLE_DIST_CM) {
    if (!vehicleInA && (now - lastCooldownA >= VEHICLE_COOLDOWN)) {
      vehicleInA = true;
      vehicleCountA++;
      vehiclePerMinA++;
      lastCooldownA = now;
      Serial.print(F("[Traffic A] Vehicle! Total:"));
      Serial.print(vehicleCountA);
      Serial.print(F("  PerMin:"));
      Serial.println(vehiclePerMinA);
    }
  } else {
    vehicleInA = false;
  }

  // Small delay to prevent cross-echo interference
  delay(30);

  // Lane B — shared TRIG + ECHO_LANE_B
  float distB = readUltrasonic(TRIG_SHARED, ECHO_LANE_B);
  if (distB > 0 && distB < VEHICLE_DIST_CM) {
    if (!vehicleInB && (now - lastCooldownB >= VEHICLE_COOLDOWN)) {
      vehicleInB = true;
      vehicleCountB++;
      vehiclePerMinB++;
      lastCooldownB = now;
      Serial.print(F("[Traffic B] Vehicle! Total:"));
      Serial.print(vehicleCountB);
      Serial.print(F("  PerMin:"));
      Serial.println(vehiclePerMinB);
    }
  } else {
    vehicleInB = false;
  }

  // Per-minute reset (both lanes)
  if (now - lastMinReset >= 60000UL) {
    laneAStatus = vehiclePerMinA >= 10 ? "congested" : vehiclePerMinA >= 5 ? "moderate" : "clear";
    laneBStatus = vehiclePerMinB >= 10 ? "congested" : vehiclePerMinB >= 5 ? "moderate" : "clear";
    vehiclePerMinA = 0;
    vehiclePerMinB = 0;
    lastMinReset   = now;
  }
}

// ════════════════════════════════════════════════
//  READ WASTE BIN — Both bins LIVE
// ════════════════════════════════════════════════
void readWaste(uint32_t now) {
  // Bin 1 — real HC-SR04 (shared TRIG + ECHO_BIN1)
  float sum = 0; int valid = 0;
  for (int i = 0; i < 3; i++) {
    float d = readUltrasonic(TRIG_SHARED, ECHO_BIN1);
    if (d > 0 && d <= BIN_HEIGHT_CM * 1.2f) { sum += d; valid++; }
    delay(20);
  }
  if (valid > 0) {
    float dist = sum / valid;
    bin1Level = constrain((1.0f - dist/BIN_HEIGHT_CM)*100.0f, 0.0f, 100.0f);
  }

  // Small delay between sensors to avoid cross-echo
  delay(30);

  // Bin 2 — real HC-SR04 (shared TRIG + ECHO_BIN2)
  sum = 0; valid = 0;
  for (int i = 0; i < 3; i++) {
    float d = readUltrasonic(TRIG_SHARED, ECHO_BIN2);
    if (d > 0 && d <= BIN_HEIGHT_CM * 1.2f) { sum += d; valid++; }
    delay(20);
  }
  if (valid > 0) {
    float dist = sum / valid;
    bin2Level = constrain((1.0f - dist/BIN_HEIGHT_CM)*100.0f, 0.0f, 100.0f);
  }

  // Bin reset commands from ESP
  if (cmdBin1Reset) {
    bin1Level = 3.0f;
    cmdBin1Reset = false;
    Serial.println(F("[Waste] Bin 1 collected & reset"));
  }
  if (cmdBin2Reset) {
    bin2Level = 3.0f;
    cmdBin2Reset = false;
    Serial.println(F("[Waste] Bin 2 collected & reset"));
  }

  bin1Status = bin1Level >= BIN_FULL ? "full" : bin1Level >= BIN_OK ? "ok" : "empty";
  bin2Status = bin2Level >= BIN_FULL ? "full" : bin2Level >= BIN_OK ? "ok" : "empty";
  wasteAlert = (bin1Status == "full" || bin2Status == "full");
}

// ════════════════════════════════════════════════
//  READ SOIL + AUTO PUMP
// ════════════════════════════════════════════════
void readSoilAndPumps() {
  soilA = readSoil(SOIL_A);
  soilB = readSoil(SOIL_B);

  if (parkMode == "auto") {
    // Zone A auto
    if (soilA < AUTO_ON_PCT  && !pumpAon) { pumpAon = true;  Serial.println("[Park] Auto: Pump A ON"); }
    if (soilA >= AUTO_OFF_PCT && pumpAon)  { pumpAon = false; Serial.println("[Park] Auto: Pump A OFF"); }
    // Zone B auto
    if (soilB < AUTO_ON_PCT  && !pumpBon) { pumpBon = true;  Serial.println("[Park] Auto: Pump B ON"); }
    if (soilB >= AUTO_OFF_PCT && pumpBon)  { pumpBon = false; Serial.println("[Park] Auto: Pump B OFF"); }
  }

  setPump(RELAY_A, pumpAon);
  setPump(RELAY_B, pumpBon);
}

// ════════════════════════════════════════════════
//  PARSE COMMAND FROM ESP
//  Format: "CMD:KEY:VALUE\n"
// ════════════════════════════════════════════════
void parseESPCommand(String& cmd) {
  cmd.trim();
  if (!cmd.startsWith("CMD:")) return;

  // Split: CMD:KEY:VALUE
  int colon1 = cmd.indexOf(':', 4);
  if (colon1 < 0) return;
  String key = cmd.substring(4, colon1);
  String val = cmd.substring(colon1 + 1);

  if (key == "PARK_MODE") {
    parkMode = val;
    Serial.println("[Park] Mode: " + val);
  } else if (key == "PUMP_A") {
    if (parkMode == "manual") { pumpAon = (val == "1"); setPump(RELAY_A, pumpAon); }
  } else if (key == "PUMP_B") {
    if (parkMode == "manual") { pumpBon = (val == "1"); setPump(RELAY_B, pumpBon); }
  } else if (key == "TRAFFIC") {
    trafficMode = val;
    if (val == "auto") manualCmd = "none";
    Serial.println("[Traffic] Mode: " + val);
  } else if (key == "SIGNAL") {
    manualCmd = val;
    Serial.println("[Signal] Command: " + val);
  } else if (key == "BIN1_RST") {
    cmdBin1Reset = true;
  } else if (key == "BIN2_RST") {
    cmdBin2Reset = true;
  }
}

// ════════════════════════════════════════════════
//  SEND DATA TO ESP (JSON)
// ════════════════════════════════════════════════
void sendToESP() {
  // "pas","pbs" = park status strings
  String pas = soilStatus(soilA);
  String pbs = soilStatus(soilB);
  String sig = signalStateName(sigState);

  espSerial.print("DATA:{");
  // Park
  espSerial.print("\"pa\":"); espSerial.print(soilA);
  espSerial.print(",\"pb\":"); espSerial.print(soilB);
  espSerial.print(",\"pas\":\""); espSerial.print(pas); espSerial.print("\"");
  espSerial.print(",\"pbs\":\""); espSerial.print(pbs); espSerial.print("\"");
  espSerial.print(",\"pua\":"); espSerial.print(pumpAon ? "true" : "false");
  espSerial.print(",\"pub\":"); espSerial.print(pumpBon ? "true" : "false");
  espSerial.print(",\"pmd\":\""); espSerial.print(parkMode); espSerial.print("\"");
  // Traffic — Lane A
  espSerial.print(",\"ta\":"); espSerial.print(vehicleCountA);
  espSerial.print(",\"tapm\":"); espSerial.print(vehiclePerMinA);
  espSerial.print(",\"las\":\""); espSerial.print(laneAStatus); espSerial.print("\"");
  // Traffic — Lane B
  espSerial.print(",\"tb\":"); espSerial.print(vehicleCountB);
  espSerial.print(",\"tbpm\":"); espSerial.print(vehiclePerMinB);
  espSerial.print(",\"lbs\":\""); espSerial.print(laneBStatus); espSerial.print("\"");
  // Signal
  espSerial.print(",\"sig\":\""); espSerial.print(sig); espSerial.print("\"");
  espSerial.print(",\"sdur\":"); espSerial.print(sigDuration / 1000);
  // Waste — both bins LIVE
  espSerial.print(",\"w1\":"); espSerial.print((int)bin1Level);
  espSerial.print(",\"w2\":"); espSerial.print((int)bin2Level);
  espSerial.print(",\"w1s\":\""); espSerial.print(bin1Status); espSerial.print("\"");
  espSerial.print(",\"w2s\":\""); espSerial.print(bin2Status); espSerial.print("\"");
  espSerial.print(",\"wa\":"); espSerial.print(wasteAlert ? "true" : "false");
  espSerial.println("}");

  // Also print to USB Serial for debug
  Serial.print(F("[Send] Soil A:")); Serial.print(soilA);
  Serial.print(F(" B:")); Serial.print(soilB);
  Serial.print(F(" | Sig:")); Serial.print(sig);
  Serial.print(F(" | Lane A:")); Serial.print(vehiclePerMinA);
  Serial.print(F("/min B:")); Serial.print(vehiclePerMinB);
  Serial.print(F("/min | Bin1:")); Serial.print((int)bin1Level);
  Serial.print(F("% Bin2:")); Serial.print((int)bin2Level);
  Serial.println(F("%"));
}

// ════════════════════════════════════════════════
//  SETUP
// ════════════════════════════════════════════════
void setup() {
  Serial.begin(9600);
  espSerial.begin(9600);
  delay(200);

  // Shared TRIG pin (for all 4 HC-SR04 sensors)
  pinMode(TRIG_SHARED, OUTPUT);
  digitalWrite(TRIG_SHARED, LOW);

  // Traffic ECHO pins (2 lanes)
  pinMode(ECHO_LANE_A, INPUT);
  pinMode(ECHO_LANE_B, INPUT);

  // Traffic LEDs
  pinMode(LED_A_RED, OUTPUT); pinMode(LED_A_YEL, OUTPUT); pinMode(LED_A_GRN, OUTPUT);
  pinMode(LED_B_RED, OUTPUT); pinMode(LED_B_YEL, OUTPUT); pinMode(LED_B_GRN, OUTPUT);

  // Waste ECHO pins (2 bins)
  pinMode(ECHO_BIN1, INPUT);
  pinMode(ECHO_BIN2, INPUT);

  // Park pins
  pinMode(RELAY_A, OUTPUT); pinMode(RELAY_B, OUTPUT);
  setPump(RELAY_A, false);
  setPump(RELAY_B, false);

  // Start with Green A
  sigState   = GREEN_A;
  sigTimer   = millis();
  sigDuration = SIG_BASE_MS;
  setSignalLEDs(GREEN_A);

  Serial.println(F("=== SMART CITY Arduino UNO v3.1 ==="));
  Serial.println(F("4 HC-SR04 sensors: Lane A, Lane B, Bin 1, Bin 2"));
  Serial.println(F("Shared TRIG pin 2 + separate ECHO pins"));
  Serial.println(F("Soil sensors warming up..."));
  delay(2000);

  // First reads
  soilA = readSoil(SOIL_A);
  soilB = readSoil(SOIL_B);

  lastMinReset = lastTrafficRead = lastWasteRead = lastSoilRead = lastSend = millis();

  Serial.println("Ready! Soil A:" + String(soilA) + "% B:" + String(soilB) + "%");
  Serial.println("Commands: 'a1/a0' Pump A, 'b1/b0' Pump B, 'auto' mode, 'g/r' signal");
}

// ════════════════════════════════════════════════
//  LOOP
// ════════════════════════════════════════════════
void loop() {
  uint32_t now = millis();

  // ── 1. Read commands from ESP ──
  while (espSerial.available()) {
    char c = espSerial.read();
    if (c == '\n') {
      parseESPCommand(espBuf);
      espBuf = "";
    } else if (espBuf.length() < 80) {
      espBuf += c;
    }
  }

  // ── 2. USB Serial debug commands ──
  if (Serial.available()) {
    String s = Serial.readStringUntil('\n');
    s.trim();
    if (s == "a1") { pumpAon = true;  parkMode = "manual"; setPump(RELAY_A, true);  Serial.println("Pump A ON"); }
    if (s == "a0") { pumpAon = false; parkMode = "manual"; setPump(RELAY_A, false); Serial.println("Pump A OFF"); }
    if (s == "b1") { pumpBon = true;  parkMode = "manual"; setPump(RELAY_B, true);  Serial.println("Pump B ON"); }
    if (s == "b0") { pumpBon = false; parkMode = "manual"; setPump(RELAY_B, false); Serial.println("Pump B OFF"); }
    if (s == "auto")  { parkMode = "manual"; trafficMode = "auto";    manualCmd = "none"; Serial.println("Auto mode"); }
    if (s == "ga")    { trafficMode = "manual"; manualCmd = "green_a"; }
    if (s == "gb")    { trafficMode = "manual"; manualCmd = "green_b"; }
    if (s == "red")   { trafficMode = "manual"; manualCmd = "red_all"; }
  }

  // ── 3. Traffic sensor (every 200ms) ──
  if (now - lastTrafficRead >= 200) {
    readTrafficSensor(now); lastTrafficRead = now;
  }

  // ── 4. Traffic signal FSM (continuous) ──
  updateSignalFSM(now);

  // ── 5. Waste bins (every 1.5s) ──
  if (now - lastWasteRead >= 1500) {
    readWaste(now); lastWasteRead = now;
  }

  // ── 6. Soil sensors + pumps (every 2s) ──
  if (now - lastSoilRead >= 2000) {
    readSoilAndPumps(); lastSoilRead = now;
  }

  // ── 7. Send data to ESP (every 3s) ──
  if (now - lastSend >= 3000) {
    sendToESP(); lastSend = now;
  }
}
