// ═══════════════════════════════════════════════════
//  auth.js — Smart City v3
//  Firebase-only session (no localStorage users DB)
// ═══════════════════════════════════════════════════

const AUTH_KEY = 'sc_auth_user';

// ── SESSION HELPERS ───────────────────────────────
function getSession()   { return JSON.parse(localStorage.getItem(AUTH_KEY) || 'null'); }
function saveSession(u) { localStorage.setItem(AUTH_KEY, JSON.stringify(u)); }
function clearSession() { localStorage.removeItem(AUTH_KEY); }
function isLoggedIn()   { return !!getSession(); }
function isAdmin()      { const s = getSession(); return s && s.role === 'admin'; }

// ── GUARDS ────────────────────────────────────────
function requireAuth(redirectTo = 'login.html') {
  if (!isLoggedIn()) { window.location.href = redirectTo; return false; }
  return true;
}
function requireAdmin() {
  if (!requireAuth()) return false;
  if (!isAdmin()) { toast('Admin access required', 'err'); window.location.href = 'index.html'; return false; }
  return true;
}
function redirectIfLoggedIn(to = 'index.html') {
  if (isLoggedIn()) window.location.href = to;
}

// ── ADMIN LOGIN (email + password — Firebase DB check) ──
async function doLogin(email, password) {
  if (!fbConnected || !db) {
    return { ok: false, msg: 'Firebase not connected. Check your firebase-config.js.' };
  }
  try {
    const snap = await db.ref(DB.users).orderByChild('email').equalTo(email.toLowerCase()).once('value');
    const data = snap.val();
    if (!data) return { ok: false, msg: 'No admin account found with this email.' };

    const uid  = Object.keys(data)[0];
    const user = data[uid];

    if (user.role !== 'admin') return { ok: false, msg: 'This login is for admins only. Use Citizen Login tab.' };
    if (user.password !== password) return { ok: false, msg: 'Incorrect password.' };

    const session = {
      id:      uid,
      name:    user.name,
      email:   user.email,
      role:    'admin',
      phone:   user.phone   || '',
      houseNo: user.houseNo || '',
      block:   user.block   || '',
      city:    user.city    || 'Faisalabad',
      avatar:  (user.name || email)[0].toUpperCase()
    };
    saveSession(session);
    return { ok: true, user: session };
  } catch(e) {
    return { ok: false, msg: 'Login error: ' + e.message };
  }
}

// ── PHONE-BASED CITIZEN SIGNIN ────────────────────
async function doPhoneSignin(name, phone, houseNo, block) {
  if (!fbConnected || !db) {
    return { ok: false, msg: 'Firebase not connected. Check your firebase-config.js.' };
  }
  const cleanPhone = phone.replace(/\s/g, '');
  return await fbPhoneSignin(name, cleanPhone, houseNo, block);
}

// ── CITIZEN SIGNUP ────────────────────────────────
async function doSignup(name, phone, houseNo, block, city) {
  if (!name.trim())  return { ok: false, msg: 'Name is required' };
  const cleanPhone = phone.replace(/\s/g, '');
  if (!cleanPhone)   return { ok: false, msg: 'Phone number is required' };
  if (!fbConnected || !db) {
    return { ok: false, msg: 'Firebase not connected. Check your firebase-config.js.' };
  }
  return await fbPhoneSignup(name, cleanPhone, houseNo, block, city);
}

// ── LOGOUT ────────────────────────────────────────
function doLogout() {
  if (typeof fbSignout === 'function' && fbConnected) { fbSignout(); return; }
  clearSession();
  window.location.href = 'login.html';
}

// ── FORGOT PASSWORD ────────────────────────────────
async function doForgot(email) {
  if (!fbConnected || !db) return { ok: false, msg: 'Firebase not connected.' };
  try {
    const snap = await db.ref(DB.users).orderByChild('email').equalTo(email.toLowerCase()).once('value');
    if (!snap.val()) return { ok: false, msg: 'No account found with this email.' };
    return { ok: true, msg: `Contact city management to reset: citymanagement@smartcity.pk (Quote: ${email})` };
  } catch(e) {
    return { ok: false, msg: 'Error: ' + e.message };
  }
}

// ── RENDER TOPBAR USER ────────────────────────────
function renderTopbarUser() {
  const s = getSession(); if (!s) return;
  const el = document.getElementById('topbar-user'); if (!el) return;
  el.innerHTML = `
    <div class="user-btn" onclick="toggleUserMenu()">
      <div class="user-avatar" style="background:linear-gradient(135deg,${s.role === 'admin' ? 'var(--teal),var(--purple)' : 'var(--green),var(--teal)'})">${s.avatar || s.name[0]}</div>
      <div>
        <div class="user-name">${s.name.split(' ')[0]}</div>
        <div class="user-role">${s.role === 'admin' ? '⚡ Admin' : '👤 Citizen'}</div>
      </div>
    </div>
    <div class="user-menu hidden" id="user-menu">
      <div class="um-item" onclick="window.location.href='index.html'">🏠 Dashboard</div>
      ${s.role === 'admin' ? '<div class="um-item" onclick="window.location.href=\'admin.html\'">⚡ Admin Panel</div>' : ''}
      ${s.role === 'admin' ? '<div class="um-item" onclick="window.location.href=\'complain.html\'">📢 Complaints</div>' : ''}
      <div class="um-sep"></div>
      <div class="um-item um-logout" onclick="doLogout()">🚪 Sign Out</div>
    </div>`;
}

function toggleUserMenu() {
  const m = document.getElementById('user-menu');
  if (m) m.classList.toggle('hidden');
}

document.addEventListener('click', e => {
  const m = document.getElementById('user-menu');
  if (m && !e.target.closest('.user-btn')) m.classList.add('hidden');
});
