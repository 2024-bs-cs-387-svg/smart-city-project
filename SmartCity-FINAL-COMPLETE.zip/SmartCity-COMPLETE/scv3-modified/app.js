// ═══════════════════════════════════════════════════
//  app.js — Smart City v3 — Full Application Logic
// ═══════════════════════════════════════════════════

/* ── CLOCK ────────────────────────────────────── */
function updateClock() {
  const n=new Date();
  setTxt('clock',  n.toLocaleTimeString('en-PK',{hour12:false}));
  setTxt('top-date',n.toLocaleDateString('en-PK',{weekday:'short',month:'short',day:'numeric'}));
}
setInterval(updateClock,1000); updateClock();

/* ── THEME ────────────────────────────────────── */
const THEME_KEY='sc_theme';
function initTheme(){
  const t=localStorage.getItem(THEME_KEY)||'dark';
  document.body.classList.toggle('light', t==='light');
  updateThemeIcon();
}
function toggleTheme(){
  document.body.classList.toggle('light');
  const t=document.body.classList.contains('light')?'light':'dark';
  localStorage.setItem(THEME_KEY,t);
  updateThemeIcon();
  toast(`${t==='light'?'☀️ Light':'🌙 Dark'} theme activated`,'info');
}
function updateThemeIcon(){
  const el=document.getElementById('theme-icon');
  if(el) el.textContent=document.body.classList.contains('light')?'🌙':'☀️';
}
initTheme();

/* ── HELPERS ──────────────────────────────────── */
function setTxt(id,v){const e=document.getElementById(id);if(e)e.textContent=v;}
function val(id){const e=document.getElementById(id);return e?e.value.trim():'';}
function bindBtn(id,fn){const e=document.getElementById(id);if(e)e.addEventListener('click',fn);}

/* ── SYSTEM STATUS DOTS ─────────────────────────── */
function renderStatusDots() {
  const right = document.querySelector('.topbar-right');
  if (!right || document.getElementById('sc-status-dots')) return;
  const style = document.createElement('style');
  style.textContent = `.sc-dot{width:8px;height:8px;border-radius:50%;display:inline-block;flex-shrink:0}.sc-dot.green{background:#1de99b}.sc-dot.red{background:#ff4d6d}.sc-dot.blink{animation:sc-blink 1.2s ease-in-out infinite}@keyframes sc-blink{0%,100%{opacity:1}50%{opacity:.25}}#sc-status-dots{display:flex;gap:10px;align-items:center;margin-right:6px}.sc-stat-item{display:flex;align-items:center;gap:4px;font-size:.6rem;color:var(--text-dim);cursor:default}`;
  document.head.appendChild(style);
  const wrap = document.createElement('div');
  wrap.id = 'sc-status-dots';
  wrap.innerHTML = `<div class="sc-stat-item" title="Firebase"><span class="sc-dot red" id="dot-firebase"></span><span>Firebase</span></div><div class="sc-stat-item" title="ESP Sensor"><span class="sc-dot red" id="dot-sensor"></span><span>ESP</span></div><div class="sc-stat-item" title="Website"><span class="sc-dot green blink" id="dot-web"></span><span>Web</span></div>`;
  right.insertBefore(wrap, right.firstChild);
}
// Track ESP heartbeat — store last seen value + when we saw it
let _espLastValue = null;
let _espLastSeenAt = 0;

function updateStatusDots() {
  const fbDot = document.getElementById('dot-firebase');
  if(fbDot) fbDot.className = 'sc-dot '+(fbConnected?'green blink':'red');
  if(db && fbConnected) {
    db.ref('/system/last_seen').once('value').then(snap => {
      const v = snap.val();
      const now = Date.now();
      // If value changed → ESP is alive (sending heartbeat)
      if (v !== null && v !== _espLastValue) {
        _espLastValue  = v;
        _espLastSeenAt = now;
      }
      // ESP fresh = we saw a change in last 20 seconds
      const fresh = _espLastSeenAt > 0 && (now - _espLastSeenAt) < 20000;
      const eDot = document.getElementById('dot-sensor');
      if(eDot) eDot.className = 'sc-dot '+(fresh?'green blink':'red');
    }).catch(()=>{});
  }
}

/* ── CMD WRITE ─────────────────────────────────── */
async function writeCmd(path, value) {
  if (!db || !fbConnected) { toast('Firebase not connected','err'); return false; }
  try { await db.ref('commands/' + path).set(value); return true; }
  catch(e) { toast('Command failed','err'); return false; }
}

function toast(msg,type='ok'){
  document.querySelectorAll('.toast').forEach(t=>t.remove());
  const t=document.createElement('div');
  t.className=`toast ${type}`;t.textContent=msg;
  document.body.appendChild(t);
  setTimeout(()=>t.remove(),3200);
}

/* ── CHART DEFAULTS ───────────────────────────── */
const isLight=()=>document.body.classList.contains('light');
function chartColors(){return{grid:isLight()?'rgba(0,0,0,.06)':'rgba(255,255,255,.04)',tick:isLight()?'#6b7f9a':'#5a7a99'};}
const CD={responsive:true,maintainAspectRatio:false,
  plugins:{legend:{labels:{color:'#5a7a99',font:{size:10,family:'DM Sans'},boxWidth:12},position:'bottom'},
    tooltip:{backgroundColor:'#0e1e35',borderColor:'rgba(0,200,220,.3)',borderWidth:1,titleColor:'#ddeeff',bodyColor:'#8aaabb'}},
  scales:{x:{grid:{color:'rgba(255,255,255,.03)'},ticks:{color:'#5a7a99',font:{size:9}}},
          y:{grid:{color:'rgba(255,255,255,.04)'},ticks:{color:'#5a7a99',font:{size:9}}}}};
function mkChart(id,type,labels,datasets,extra={}){
  const el=document.getElementById(id);if(!el)return null;
  const ex=Chart.getChart(el);if(ex)ex.destroy();
  const o=JSON.parse(JSON.stringify(CD));
  if(type==='doughnut'||type==='pie')delete o.scales;
  return new Chart(el,{type,data:{labels,datasets},options:{...o,...extra}});
}

/* ── LIVE CHART HELPER ─────────────────────────
   Pushes new data point to chart, keeps max N points,
   auto-scrolls label to show live time */
function pushChartLive(chartId, value, maxPoints = 20) {
  const el = document.getElementById(chartId);
  if (!el) return;
  const ch = Chart.getChart(el);
  if (!ch) return;
  const now = new Date();
  const lbl = now.toLocaleTimeString('en-US',{hour12:false,minute:'2-digit',second:'2-digit'});

  // Support single value or array for multi-dataset charts
  if (Array.isArray(value)) {
    value.forEach((v,i)=>{ if(ch.data.datasets[i]) ch.data.datasets[i].data.push(v); });
  } else {
    ch.data.datasets[0].data.push(value);
  }
  ch.data.labels.push(lbl);

  // Trim to maxPoints
  while (ch.data.labels.length > maxPoints) {
    ch.data.labels.shift();
    ch.data.datasets.forEach(ds => ds.data.shift());
  }
  ch.update('none');
}
window.pushChartLive = pushChartLive;
function rnd(n,mn,mx,dc=1){return Array.from({length:n},()=>+((Math.random()*(mx-mn)+mn).toFixed(dc)));}
const H24=()=>Array.from({length:24},(_,i)=>`${String(i).padStart(2,'0')}:00`);
const DAYS=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];

/* ══════════════════════════════════════════════
   WATER MODULE — YF-S201 LIVE (no valve control)
══════════════════════════════════════════════ */
let waterState={flow:0,total:0,status:'starting',leakDetected:false,timer:null,chart:null};

function initWaterPage(){
  if(!fbConnected){
    waterState={...waterState,...DEMO.water,flow:DEMO.water.flow_rate,total:DEMO.water.total_liters};
    waterState.timer=setInterval(tickWaterDemo,3000);
  }
  const hist=rnd(24,8,18);
  waterState.chart=mkChart('water-chart','line',H24(),[{
    label:'Flow L/min',data:[...hist],
    borderColor:'#00c8dc',backgroundColor:'rgba(0,200,220,.10)',tension:.4,fill:true,pointRadius:2
  }]);
  mkChart('water-daily','bar',['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],[{label:'Liters',data:rnd(7,200,380,0),backgroundColor:'rgba(0,200,220,.5)',borderRadius:5}]);
  mkChart('water-hourly','line',H24(),[
    {label:'Flow (L/min)',data:rnd(24,6,20),borderColor:'#1de99b',backgroundColor:'rgba(29,233,155,.08)',tension:.4,fill:true,pointRadius:0}
  ]);
  mkChart('water-weekly','bar',['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],[
    {label:'Total (L)',data:rnd(7,1800,3500,0),backgroundColor:'rgba(167,139,250,.55)',borderRadius:5}
  ]);
  renderWaterUI();
}

function tickWaterDemo(){
  const d=(Math.random()-.45)*1.5;
  waterState.flow=Math.max(0.5,+(waterState.flow+d).toFixed(1));
  waterState.total=+(waterState.total+waterState.flow*3/60).toFixed(0);
  waterState.status=waterState.flow>20?'critical':waterState.flow>16?'high':'normal';
  renderWaterUI();
  if(waterState.chart){const d2=waterState.chart.data.datasets[0].data;d2.shift();d2.push(waterState.flow);waterState.chart.update('none');}
}

function renderWaterUI(){
  const s=waterState;
  setTxt('w-flow', s.flow.toFixed?s.flow.toFixed(1):s.flow);
  setTxt('w-flow-r',`${(+s.flow).toFixed(1)} L/min`);
  setTxt('w-total', `${(+s.total).toFixed(0)} L`);
  setTxt('s-flow',  (+s.flow).toFixed(1));
  setTxt('s-total', `${(+s.total).toFixed(0)}L`);
  setTxt('w-ts',    new Date().toLocaleTimeString('en-PK'));
  setTxt('w-ts2',   new Date().toLocaleTimeString('en-PK'));
  setTxt('w-status',s.status.toUpperCase());
  const stEl=document.getElementById('w-status');
  if(stEl) stEl.className=`dv ${s.status==='normal'?'g':s.status==='high'?'a':'r'}`;
  const badge=document.getElementById('w-badge');
  if(badge){badge.className=`wsb ${s.status==='normal'?'n':s.status==='high'?'h':'c'}`;
    badge.textContent={normal:'✅ Normal Flow',high:'⚠ High Flow',critical:'🚨 CRITICAL FLOW',idle:'○ Idle'}[s.status]||s.status;}
  const aok=document.getElementById('w-alert-ok');
  const aerr=document.getElementById('w-alert-critical');
  if(aok)  aok.style.display=s.status==='critical'?'none':'flex';
  if(aerr) aerr.style.display=s.status==='critical'?'flex':'none';
  setTxt('dht-source',fbConnected?'🔴 Live — YF-S201 via Firebase':'⚪ Offline — Connect Firebase for live data');
}

/* ══════════════════════════════════════════════
   WEATHER MODULE — DHT22 LIVE + OPEN-METEO API
══════════════════════════════════════════════ */
const FAISALABAD={lat:31.4504,lon:73.135};
const WMO={0:{d:'Clear Sky',e:'☀️'},1:{d:'Mainly Clear',e:'🌤️'},2:{d:'Partly Cloudy',e:'⛅'},3:{d:'Overcast',e:'☁️'},45:{d:'Foggy',e:'🌫️'},51:{d:'Drizzle',e:'🌦️'},61:{d:'Rain',e:'🌧️'},63:{d:'Heavy Rain',e:'🌧️'},71:{d:'Snow',e:'❄️'},80:{d:'Showers',e:'🌦️'},95:{d:'Thunderstorm',e:'⛈️'}};
let wthState={temp:27.8,hum:60.1,feels:27.8,dew:19.3,pres:1013,wind:12,desc:'Loading…',emoji:'⏳',uv:'—'};

async function initWeatherPage(){
  renderDHT22UI();
  mkChart('temp-chart','line',H24(),[{label:'Temp °C',data:rnd(24,22,32),borderColor:'#a78bfa',backgroundColor:'rgba(167,139,250,.10)',tension:.4,fill:true,pointRadius:0}]);
  mkChart('humid-chart','line',H24(),[{label:'Humidity %',data:rnd(24,50,80),borderColor:'#00c8dc',backgroundColor:'rgba(0,200,220,.10)',tension:.4,fill:true,pointRadius:0}]);
  mkChart('pressure-chart','line',H24(),[{label:'hPa',data:rnd(24,1008,1018),borderColor:'#1de99b',backgroundColor:'rgba(29,233,155,.08)',tension:.4,fill:true,pointRadius:0}]);
  setTxt('w-api-status','⏳ Fetching 7-day forecast from Open-Meteo…');
  try{
    const url=`https://api.open-meteo.com/v1/forecast?latitude=${FAISALABAD.lat}&longitude=${FAISALABAD.lon}&current=temperature_2m,weather_code,surface_pressure,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=Asia%2FKarachi&forecast_days=7`;
    const res=await fetch(url); const data=await res.json();
    const cur=data.current;
    const wi=WMO[cur.weather_code]||{d:'—',e:'🌡️'};
    wthState.desc=wi.d; wthState.emoji=wi.e;
    wthState.pres=Math.round(cur.surface_pressure);
    wthState.wind=Math.round(cur.wind_speed_10m);
    if(data.daily) buildForecast(data.daily);
    setTxt('w-api-status','✅ Open-Meteo forecast loaded · DHT22 readings are live from ESP8266');
    toast('✅ Live weather data loaded!','ok');
  }catch(e){
    setTxt('w-api-status','⚠️ Open-Meteo API unavailable — showing DHT22 sensor data only');
  }
  renderDHT22UI();
  bindBtn('btn-refresh-weather',()=>{toast('🔄 Refreshing…','info');initWeatherPage();});
}

function renderDHT22UI(){
  setTxt('wh-temp',  `${(+wthState.temp).toFixed(1)}°C`);
  setTxt('wh-emoji', wthState.emoji||'🌡️');
  setTxt('wh-desc',  `${wthState.desc} · Faisalabad`);
  setTxt('wh-feels', `Feels like ${(+wthState.feels).toFixed(1)}°C · DHT22 Sensor`);
  setTxt('whs-hum',  `${(+wthState.hum).toFixed(1)}%`);
  setTxt('whs-pres', `${wthState.pres} hPa`);
  setTxt('whs-dew',  `${(+wthState.dew).toFixed(1)}°C`);
  setTxt('whs-wind', `${wthState.wind} km/h`);
  setTxt('s-temp',   `${(+wthState.temp).toFixed(1)}°C`);
  setTxt('s-hum',    `${(+wthState.hum).toFixed(1)}%`);
  setTxt('s-pres',   `${wthState.pres} hPa`);
  setTxt('s-wind',   `${wthState.wind} km/h`);
  setTxt('dht-source', fbConnected ? '🔴 Live — DHT22 via Firebase' : '⚪ Offline — Connect Firebase for live');
}

function buildForecast(daily){
  const fc=document.getElementById('forecast-row');if(!fc)return;
  const N=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  fc.innerHTML=daily.weather_code.slice(0,7).map((wc,i)=>{
    const wi=WMO[wc]||{e:'🌡️'};const d=new Date(daily.time[i]);
    return `<div class="fc-day"><div class="fc-name">${N[d.getDay()]}</div><div class="fc-icon">${wi.e}</div><div class="fc-hi">${Math.round(daily.temperature_2m_max[i])}°</div><div class="fc-lo">${Math.round(daily.temperature_2m_min[i])}°</div></div>`;
  }).join('');
}

/* ══════════════════════════════════════════════
   COMPLAINT MODULE — Firebase Realtime + Local fallback
══════════════════════════════════════════════ */
const C_KEY='sc_complaints';
let nextCId=100;
let allComplaintsCache=[];

function getComplaints(){return JSON.parse(localStorage.getItem(C_KEY)||'null')||defaultComplaints();}
function saveComplaints(c){localStorage.setItem(C_KEY,JSON.stringify(c));}
function defaultComplaints(){
  const c=[
    {id:1,title:'Streetlight not working',desc:'Light at Intersection B off for 3 days. Causing safety issues at night.',loc:'Intersection B',cat:'Street Lighting',status:'progress',priority:'High',date:'Apr 4, 2026',user:'Ahmed Khan',userId:'user-1',createdAt:Date.now()-86400000},
    {id:2,title:'Garbage overflow — Market',desc:'Bin #2 overflowing near market entrance. Smelly and unhygienic.',loc:'Market Area',cat:'Waste Collection',status:'open',priority:'Critical',date:'Apr 5, 2026',user:'Sara Ali',userId:'user-2',createdAt:Date.now()-72000000},
    {id:3,title:'Water pipe leakage',desc:'Pipe near Block C dripping constantly for 2 days. Water is wasting.',loc:'Block C, Main Road',cat:'Water Leakage',status:'open',priority:'High',date:'Apr 5, 2026',user:'Demo User',userId:'user-demo',createdAt:Date.now()-60000000},
    {id:4,title:'Traffic signal stuck on red',desc:'Intersection D red light stuck for 2 hours causing traffic jams.',loc:'Intersection D',cat:'Traffic Signal',status:'resolved',priority:'Medium',date:'Apr 3, 2026',user:'Ahmed Khan',userId:'user-1',createdAt:Date.now()-172800000},
    {id:5,title:'Large road pothole',desc:'Large pothole near hospital entrance. Vehicles are getting damaged.',loc:'Hospital Road',cat:'Road Damage',status:'open',priority:'High',date:'Apr 4, 2026',user:'Demo User',userId:'user-demo',createdAt:Date.now()-86400000},
  ];
  saveComplaints(c); return c;
}

let cFilter='all';

function initComplaintPage(){
  const s=getSession();
  // If Firebase connected, use real-time listener (startComplaintsListener called in firebase-config.js)
  if(!fbConnected){
    allComplaintsCache=getComplaints();
    renderComplaintList(allComplaintsCache);
    updateCStats(allComplaintsCache);
  }
  buildComplaintCharts();
  document.querySelectorAll('.filter-btn').forEach(btn=>{
    btn.addEventListener('click',()=>{
      cFilter=btn.dataset.filter;
      document.querySelectorAll('.filter-btn').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      renderComplaintList(allComplaintsCache);
    });
  });
  bindBtn('submit-complaint',submitComplaint);
  // Show admin section header
  const adminSection=document.getElementById('admin-only-section');
  if(adminSection) adminSection.style.display=isAdmin()?'block':'none';
  // Show submit form always
  const submitSection=document.getElementById('submit-section');
  if(submitSection) submitSection.style.display='block';
  // Pre-fill name if logged in
  if(s){const cn=document.getElementById('c-name');if(cn)cn.value=s.name;}
}

// Called by Firebase listener (real-time)
function renderComplaintListFromFb(list){
  allComplaintsCache=list;
  renderComplaintList(list);
  updateCStats(list);
  buildComplaintCharts(list);
}

// Also called by admin page
function updateAdminComplaintFeed(list){
  allComplaintsCache=list;
  renderAdminComplaints(list);
  renderAdminStats();
}

function buildComplaintCharts(list){
  const complaints=list||getComplaints();
  mkChart('c-donut','doughnut',['Open','In Progress','Resolved'],[{
    data:[complaints.filter(c=>c.status==='open').length,complaints.filter(c=>c.status==='progress').length,complaints.filter(c=>c.status==='resolved').length],
    backgroundColor:['rgba(255,77,109,.8)','rgba(0,200,220,.8)','rgba(29,233,155,.8)'],borderWidth:0
  }]);
  const days=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  mkChart('c-trend','line',days,[{label:'Complaints',data:[3,2,4,1,2,1,1],borderColor:'#a78bfa',backgroundColor:'rgba(167,139,250,.1)',tension:.4,fill:true,pointRadius:3}]);
}

function renderComplaintList(complaintsIn){
  const s=getSession();
  let complaints=complaintsIn||getComplaints();
  // User sees only their own; admin sees all
  if(s&&s.role!=='admin') complaints=complaints.filter(c=>c.userId===s.id||c.userId===s.email||c.userPhone===s.phone);
  if(cFilter!=='all') complaints=complaints.filter(c=>c.status===cFilter);
  const l=document.getElementById('c-list');if(!l)return;
  if(!complaints.length){l.innerHTML='<div style="text-align:center;color:var(--text-dim);padding:24px;font-size:.8rem;">No complaints found.</div>';return;}
  l.innerHTML=complaints.map(c=>`
    <div class="ci">
      <span class="cb ${c.status==='open'?'op':c.status==='progress'?'pr':'rs'}">${c.status==='open'?'Open':c.status==='progress'?'In Progress':'Resolved'}</span>
      <div style="flex:1;">
        <div class="c-title">${c.title}<span class="pri-badge pri-${c.priority}">${c.priority}</span></div>
        <div class="c-desc">${c.desc}</div>
        <div class="c-meta">📍 ${c.loc} · 🏷️ ${c.cat} · 📅 ${c.date||'—'} · 👤 ${c.user}</div>
        <div class="c-actions">
          ${isAdmin()&&c.status!=='progress'?`<button class="btn btn-outline btn-sm" onclick="updateCStatus('${c.fbKey||c.id}','progress',${!c.fbKey})">🔵 In Progress</button>`:''}
          ${isAdmin()&&c.status!=='resolved'?`<button class="btn btn-success btn-sm" onclick="updateCStatus('${c.fbKey||c.id}','resolved',${!c.fbKey})">✅ Resolve</button>`:''}
          ${isAdmin()?`<button class="btn btn-danger btn-sm" onclick="deleteCById('${c.fbKey||c.id}',${!c.fbKey})">🗑 Delete</button>`:''}
        </div>
      </div>
    </div>`).join('');
  updateCStats(complaintsIn||allComplaintsCache);
}

function updateCStats(list){
  const all=list||(fbConnected?allComplaintsCache:getComplaints());
  setTxt('c-total',all.length);
  setTxt('c-open',all.filter(c=>c.status==='open').length);
  setTxt('c-prog',all.filter(c=>c.status==='progress').length);
  setTxt('c-res',all.filter(c=>c.status==='resolved').length);
}

async function updateCStatus(id, status, isLocal=false){
  if(!isLocal && fbConnected && typeof fbUpdateComplaintStatus==='function'){
    await fbUpdateComplaintStatus(id, status);
    toast(`✅ Complaint → ${status}`,'ok');
  } else {
    const c=getComplaints();const i=c.findIndex(x=>x.id==id);
    if(i>-1){c[i].status=status;saveComplaints(c);renderComplaintList(c);toast(`Complaint → ${status}`,'ok');}
  }
}
window.updateCStatus=updateCStatus;

async function deleteCById(id, isLocal=false){
  if(!isLocal && fbConnected && typeof fbDeleteComplaint==='function'){
    await fbDeleteComplaint(id);
    toast('Complaint removed','info');
  } else {
    const c=getComplaints();saveComplaints(c.filter(x=>x.id!=id));renderComplaintList(c.filter(x=>x.id!=id));toast('Removed','info');
  }
}
window.deleteCById=deleteCById;

async function submitComplaint(){
  const s=getSession();if(!s){toast('Please login to submit a complaint','err');return;}
  const name=val('c-name'),loc=val('c-loc'),cat=val('c-cat'),desc=val('c-desc'),pri=val('c-priority');
  if(!name||!loc||!desc){toast('Please fill all required fields','err');return;}
  const complaint={
    title:`${cat} Issue`,
    desc, loc, cat,
    status:'open',
    priority:pri||'Medium',
    date:new Date().toLocaleDateString('en-PK',{day:'numeric',month:'short',year:'numeric'}),
    user:s.name,
    userId:s.id,
    userEmail:s.email||'',
    userPhone:s.phone||'',
    userBlock:s.block||'',
    userHouseNo:s.houseNo||'',
    createdAt:Date.now()
  };
  const btn=document.getElementById('submit-complaint');
  if(btn){btn.disabled=true;btn.textContent='Submitting…';}
  if(fbConnected && typeof fbSubmitComplaint==='function'){
    await fbSubmitComplaint(complaint);
    toast('✅ Complaint submitted — Admin will see it instantly!','ok');
  } else {
    const c=getComplaints();
    complaint.id=nextCId++;
    c.unshift(complaint);
    saveComplaints(c);
    allComplaintsCache=c;
    renderComplaintList(c);
    toast('✅ Complaint submitted successfully!','ok');
  }
  if(btn){btn.disabled=false;btn.textContent='📤 Submit Complaint';}
  ['c-name','c-contact','c-loc','c-desc'].forEach(id=>{const e=document.getElementById(id);if(e)e.value='';});
  if(s){const cn=document.getElementById('c-name');if(cn)cn.value=s.name;}
}

/* ── PARK ─────────────────────────────────────── */
let parkState={zones:[{n:'Zone A',p:28,s:'dry',pump:true},{n:'Zone B',p:62,s:'ok',pump:false}],auto:true,total:18,timer:null};
function initParkPage(){
  renderSoilGrid();
  parkState.chart=mkChart('moisture-chart','line',H24(),[{label:'Zone A %',data:rnd(24,20,75),borderColor:'#1de99b',backgroundColor:'rgba(29,233,155,.1)',tension:.4,fill:false,pointRadius:0},{label:'Zone B %',data:rnd(24,40,80),borderColor:'#00c8dc',tension:.4,fill:false,pointRadius:0}]);
  mkChart('park-water','bar',DAYS,[{label:'Water (L)',data:rnd(7,10,22,0),backgroundColor:'rgba(29,233,155,.5)',borderRadius:5}]);
  bindBtn('btn-pump-all-on',async()=>{await writeCmd('park/zone_a_pump',true);await writeCmd('park/zone_b_pump',true);await writeCmd('park/mode','manual');parkState.zones.forEach(z=>z.pump=true);parkState.auto=false;setTxt('park-auto-status','MANUAL');renderSoilGrid();toast('All pumps ON (manual)','ok');});
  bindBtn('btn-pump-all-off',async()=>{await writeCmd('park/zone_a_pump',false);await writeCmd('park/zone_b_pump',false);await writeCmd('park/mode','manual');parkState.zones.forEach(z=>z.pump=false);parkState.auto=false;setTxt('park-auto-status','MANUAL');renderSoilGrid();toast('All pumps OFF (manual)','info');});
  bindBtn('btn-park-auto',async()=>{parkState.auto=!parkState.auto;const m=parkState.auto?'auto':'manual';await writeCmd('park/mode',m);setTxt('park-auto-status',parkState.auto?'AUTO':'MANUAL');toast(`Park: ${m.toUpperCase()} mode`,'info');renderSoilGrid();});
  bindBtn('btn-water-reset',()=>{parkState.total=0;setTxt('park-water-total','0 L');toast('Total reset','info');});
  parkState.timer=setInterval(tickPark,4000);
}
function tickPark(){
  parkState.zones.forEach(z=>{
    if(z.pump&&z.p<100)z.p=Math.min(100,+(z.p+Math.random()*3).toFixed(0));
    else if(!z.pump&&z.p>0)z.p=Math.max(0,+(z.p-Math.random()*1.5).toFixed(0));
    z.s=z.p<30?'dry':z.p>70?'wet':'ok';
    if(parkState.auto){if(z.p<30&&!z.pump){z.pump=true;toast(`💧 Auto: ${z.n} pump ON`,'info');}if(z.p>=75&&z.pump){z.pump=false;toast(`✅ Auto: ${z.n} pump OFF`,'ok');}}
  });
  parkState.total=+(parkState.total+parkState.zones.filter(z=>z.pump).length*.05).toFixed(1);
  setTxt('park-water-total',`${parkState.total} L`);
  renderSoilGrid();
}
function renderSoilGrid(){
  const g=document.getElementById('soil-grid');if(!g)return;
  g.innerHTML=parkState.zones.map((z,i)=>{
    const key=['a','b'][i];
    const statusLbl=z.s==='dry'?'🏜️ Dry':z.s==='wet'?'💧 Wet':'✅ Optimal';
    const modeBadge=`<span style="font-size:.56rem;padding:1px 5px;border-radius:3px;background:${parkState.auto?'rgba(29,233,155,.15)':'rgba(167,139,250,.15)'};color:${parkState.auto?'var(--green)':'var(--purple)'}">${parkState.auto?'AUTO':'MAN'}</span>`;
    return `<div class="soil-card"><div class="sg ${z.s}">${z.p}%</div><div style="font-size:.72rem;font-weight:600;margin:4px 0 2px">${z.n} ${modeBadge}</div><div style="font-size:.62rem;color:var(--text-dim);margin-bottom:8px">${statusLbl}</div><div style="display:flex;gap:5px;justify-content:center;flex-wrap:wrap"><button class="btn btn-sm ${z.pump?'btn-danger':'btn-success'}" onclick="toggleZone(${i})">${z.pump?'⏹ Stop':'▶ Start'}</button><button class="btn btn-outline btn-sm" onclick="manualWater(${i})">+10%</button></div></div>`;
  }).join('');
  const pb=document.getElementById('pump-box');const ac=parkState.zones.filter(z=>z.pump).length;
  if(pb)pb.className=`pump-box ${ac>0?'running':''}`;
  setTxt('pump-state',ac>0?`● Running — ${ac} zone(s) active`:'○ All pumps idle');
  const dry=parkState.zones.filter(z=>z.s==='dry').length;
  const dryEl=document.getElementById('park-dry-zones');if(dryEl)dryEl.textContent=dry;
}
async function toggleZone(i){const key=['a','b'][i];parkState.zones[i].pump=!parkState.zones[i].pump;await writeCmd('park/zone_'+key+'_pump',parkState.zones[i].pump);await writeCmd('park/mode','manual');parkState.auto=false;setTxt('park-auto-status','MANUAL');toast(`${parkState.zones[i].n} pump ${parkState.zones[i].pump?'ON':'OFF'}`,'info');renderSoilGrid();}
function manualWater(i){parkState.zones[i].p=Math.min(100,parkState.zones[i].p+10);renderSoilGrid();toast(`${parkState.zones[i].n} +10%`,'ok');}
window.toggleZone=toggleZone; window.manualWater=manualWater;

/* ── TRAFFIC ──────────────────────────────────── */
let tlStates=[{r:false,y:false,g:true},{r:true,y:false,g:false}];
let tlCounts=[0,0];
let tlAuto=true,tlTimer=null;
function initTrafficPage(){
  buildTL();tlTimer=setInterval(()=>{if(tlAuto)cycleTL();},3200);
  mkChart('traffic-chart','line',[],[
    {label:'Lane A (/min)',data:[],borderColor:'#00c8dc',backgroundColor:'rgba(0,200,220,.15)',tension:.4,fill:true,pointRadius:3},
    {label:'Lane B (/min)',data:[],borderColor:'#1de99b',backgroundColor:'rgba(29,233,155,.10)',tension:.4,fill:false,pointRadius:3}
  ]);
  bindBtn('btn-tl-auto',async()=>{tlAuto=!tlAuto;const m=tlAuto?'auto':'manual';await writeCmd('traffic/mode',m);if(!tlAuto)await writeCmd('traffic/signal','none');document.getElementById('btn-tl-auto').textContent=`🔄 Auto: ${tlAuto?'ON':'OFF'}`;toast(`Traffic: ${m.toUpperCase()} mode`,'info');});
  bindBtn('btn-force-green-a',async()=>{tlAuto=false;document.getElementById('btn-tl-auto').textContent='🔄 Auto: OFF';await writeCmd('traffic/mode','manual');await writeCmd('traffic/signal','green_a');toast('Lane A → GREEN','ok');});
  bindBtn('btn-force-green-b',async()=>{tlAuto=false;document.getElementById('btn-tl-auto').textContent='🔄 Auto: OFF';await writeCmd('traffic/mode','manual');await writeCmd('traffic/signal','green_b');toast('Lane B → GREEN','ok');});
  bindBtn('btn-force-red-all',async()=>{tlAuto=false;document.getElementById('btn-tl-auto').textContent='🔄 Auto: OFF';await writeCmd('traffic/mode','manual');await writeCmd('traffic/signal','red_all');toast('ALL SIGNALS → RED','err');});
  bindBtn('btn-emergency-a',async()=>{await writeCmd('traffic/mode','manual');await writeCmd('traffic/signal','emergency_a');toast('🚨 EMERGENCY: Lane A opened (5 min)','err');});
  bindBtn('btn-emergency-b',async()=>{await writeCmd('traffic/mode','manual');await writeCmd('traffic/signal','emergency_b');toast('🚨 EMERGENCY: Lane B opened (5 min)','err');});
}
function buildTL(){const c=document.getElementById('tl-row');if(!c)return;c.innerHTML=['A','B'].map((n,i)=>{const s=tlStates[i]||{r:false,y:false,g:false};return`<div class="tl-box"><div class="tl-name">Lane ${n}</div><div class="tl-lc"><div class="tl-l lr ${s.r?'on':''}"></div><div class="tl-l ly ${s.y?'on':''}"></div><div class="tl-l lg ${s.g?'on':''}"></div></div><div class="tl-cars" id="tl-cars-${i}">${tlCounts[i]||0} cars</div></div>`;}).join('');}
function cycleTL(){/* no-op — ESP controls signals */}
function tlForce(i,col){/* handled by writeCmd from top buttons */}
window.tlForce=tlForce;

/* ── STREET LIGHTS ────────────────────────────── */
let lights=[
  {n:'Zone A',on:false,lux:0,motion:false,live:true,  zKey:'',        mode:'auto'},  // ESP D5 — sensor + manual
  {n:'Zone B',on:false,lux:0,motion:false,live:true,  zKey:'zone_b',  mode:'auto'},  // ESP D0 — manual
  {n:'Zone C',on:false,lux:0,motion:false,live:true,  zKey:'zone_c',  mode:'auto'},  // ESP D6 — manual (2 LEDs parallel)
  {n:'Zone D',on:false,lux:0,motion:false,live:false, zKey:'',        mode:'auto'}   // simulated only
];
let streetGlobalMode='auto';   // current global mode from website
function initStreetPage(){
  renderLG();
  mkChart('energy-chart','line',['6pm','7pm','8pm','9pm','10pm','11pm','12am','1am','2am','3am','4am','5am'],[{label:'kWh',data:[2.1,1.8,.4,.3,.3,.4,.3,.3,.4,.8,1.4,1.9],borderColor:'#ffd166',backgroundColor:'rgba(255,209,102,.12)',tension:.4,fill:true,pointRadius:2}]);
  mkChart('brightness-chart','line',['6pm','7pm','8pm','9pm','10pm','11pm','12am','1am'],[{label:'Brightness %',data:[60,100,80,100,40,20,20,40],borderColor:'#a78bfa',backgroundColor:'rgba(167,139,250,.1)',tension:.4,fill:true}]);
  bindBtn('btn-all-on',async()=>{
    await writeCmd('street/mode','on');
    await writeCmd('street/zone_b','on');
    await writeCmd('street/zone_c','on');
    streetGlobalMode='on';
    lights.forEach(l=>{l.on=true;l.mode='on';});
    renderLG();
    setStreetModeBadge('on');
    toast('All Lights FORCED ON','ok');
  });
  bindBtn('btn-all-off',async()=>{
    await writeCmd('street/mode','off');
    await writeCmd('street/zone_b','off');
    await writeCmd('street/zone_c','off');
    streetGlobalMode='off';
    lights.forEach(l=>{l.on=false;l.mode='off';});
    renderLG();
    setStreetModeBadge('off');
    toast('All Lights FORCED OFF','info');
  });
  bindBtn('btn-auto-all',async()=>{
    await writeCmd('street/mode','auto');
    await writeCmd('street/zone_b','auto');
    await writeCmd('street/zone_c','auto');
    streetGlobalMode='auto';
    lights.forEach(l=>l.mode='auto');
    renderLG();
    setStreetModeBadge('auto');
    toast('AUTO mode: All zones use LDR + PIR','ok');
  });
}

function renderLG(){
  const g=document.getElementById('lg-grid');if(!g)return;
  g.innerHTML=lights.map((l,i)=>{
    const liveBadge = l.live
      ? '<span style="font-size:.55rem;background:rgba(29,233,155,.18);color:var(--green);padding:1px 5px;border-radius:3px;margin-left:4px">● LIVE</span>'
      : '<span style="font-size:.55rem;background:rgba(120,120,120,.18);color:var(--text-dim);padding:1px 5px;border-radius:3px;margin-left:4px">○ SIM</span>';
    // Zone A shows motion (it's the sensor zone), other live zones show their mode
    const subInfo = i===0
      ? (l.motion ? '<div style="font-size:.58rem;color:var(--green);margin-top:2px">🏃 Motion</div>' : '<div style="font-size:.58rem;color:var(--text-dim);margin-top:2px">○ No motion</div>')
      : `<div style="font-size:.58rem;color:var(--teal);margin-top:2px">Mode: ${(l.mode||'auto').toUpperCase()}</div>`;
    const sensorInfo = i===0
      ? `<div style="font-size:.58rem;color:var(--text-dim);margin-top:2px">${l.live?(l.lux>500?'☀️ DAY':'🌙 NIGHT'):'simulated'}</div>`
      : `<div style="font-size:.58rem;color:var(--text-dim);margin-top:2px">${l.live?'Independent':'simulated'}</div>`;
    return `
    <div class="li ${l.on?'on':''}" style="cursor:default">
      <div class="li-icon">${l.on?'💡':'🌑'}</div>
      <div class="li-name">${l.n} ${liveBadge}</div>
      <div class="li-st ${l.on?'on':'off'}">${l.on?'● ON':'○ OFF'}</div>
      ${sensorInfo}
      ${subInfo}
      <div style="display:flex;gap:5px;justify-content:center;margin-top:8px;flex-wrap:wrap">
        <button class="btn btn-success btn-sm" onclick="zoneLight(${i},'on')">💡 ON</button>
        <button class="btn btn-danger btn-sm" onclick="zoneLight(${i},'off')">🌑 OFF</button>
        <button class="btn btn-amber btn-sm" onclick="zoneLight(${i},'auto')">🤖 AUTO</button>
      </div>
    </div>`;
  }).join('');
  setTxt('lights-on-count',lights.filter(l=>l.on).length+'/4');
}

async function zoneLight(i,mode){
  const l = lights[i];

  if(i===0){
    // Zone A — controls global street/mode (sensor + override)
    await writeCmd('street/mode',mode);
    streetGlobalMode = mode;
    setStreetModeBadge(mode);
    l.mode = mode;
    if(mode==='on')  l.on=true;
    if(mode==='off') l.on=false;
    toast(`Zone A: ${mode.toUpperCase()} (LIVE)`,'ok');
  }
  else if(l.live && l.zKey){
    // Zone B / Zone C — write to specific zone command
    await writeCmd('street/'+l.zKey, mode);
    l.mode = mode;
    if(mode==='on')  l.on=true;
    if(mode==='off') l.on=false;
    // 'auto' will follow Zone A logic via ESP
    toast(`${l.n}: ${mode.toUpperCase()} (LIVE)`,'ok');
  }
  else {
    // Zone D — pure simulation
    l.mode = mode;
    if(mode==='on')  { l.on=true;  toast(`${l.n}: ON (simulated)`,'info'); }
    if(mode==='off') { l.on=false; toast(`${l.n}: OFF (simulated)`,'info'); }
    if(mode==='auto'){ l.on=lights[0].on; toast(`${l.n}: AUTO (follows Zone A)`,'info'); }
  }
  renderLG();
}
window.zoneLight=zoneLight;

function toggleLight(i){lights[i].on=!lights[i].on;renderLG();toast(`${lights[i].n}: ${lights[i].on?'ON':'OFF'}`,'info');}
function setStreetModeBadge(mode){const el=document.getElementById('street-current-mode');if(!el)return;const map={on:{t:'FORCED ON',c:'var(--green)'},off:{t:'FORCED OFF',c:'var(--red)'},auto:{t:'AUTO (LDR+PIR)',c:'var(--teal)'}};const m=map[mode]||map.auto;el.textContent=m.t;el.style.color=m.c;}
window.toggleLight=toggleLight;

/* ── WASTE ────────────────────────────────────── */
let bins=[{n:'Bin #1',loc:'Residential Block A',p:42,cls:'l'},{n:'Bin #2',loc:'Market Area',p:35,cls:'l'}];
function initWastePage(){
  renderBins();
  mkChart('waste-chart','bar',bins.map(b=>b.n),[{label:'Fill %',data:bins.map(b=>b.p),backgroundColor:bins.map(b=>({l:'rgba(29,233,155,.6)',m:'rgba(255,209,102,.6)',h:'rgba(245,166,35,.7)',c:'rgba(255,77,109,.8)'})[b.cls]),borderRadius:6}]);
  mkChart('waste-trend','line',DAYS,[{label:'Bin #2 %',data:[10,28,45,62,78,90,95],borderColor:'#f5a623',backgroundColor:'rgba(245,166,35,.12)',tension:.4,fill:true}]);
  bindBtn('btn-collect-all',async()=>{await writeCmd('waste/bin1_collected',true);await writeCmd('waste/bin2_collected',true);await writeCmd('waste/route_active',false);bins.forEach(b=>{b.p=0;b.cls='l';});renderBins();setTxt('waste-route-status','No active route');toast('All bins marked for collection','ok');});
  bindBtn('btn-collect-critical',async()=>{const cr=bins.filter(b=>b.p>80);if(!cr.length){toast('No critical bins','info');return;}if(bins[0]&&bins[0].p>80)await writeCmd('waste/bin1_collected',true);if(bins[1]&&bins[1].p>80)await writeCmd('waste/bin2_collected',true);cr.forEach(b=>{b.p=0;b.cls='l';});renderBins();toast('Critical bins marked for collection','ok');});
  bindBtn('btn-gen-route',()=>{const full=bins.map((b,i)=>b.p>50?`Bin #${i+1} (${b.p}%)`:'').filter(Boolean);if(!full.length){toast('No bins need collection yet','info');return;}const route='Route: Depot → '+full.join(' → ')+' → Depot';setTxt('waste-route-status',route);writeCmd('waste/route_active',true);toast('Collection route generated!','ok');});
}
function renderBins(){
  const l=document.getElementById('bin-list');if(!l)return;
  l.innerHTML=bins.map((b,i)=>{
    const col=b.p>90?'var(--red)':b.p>70?'var(--amber)':b.p>50?'var(--yellow)':'var(--green)';
    const badge=b.p>90?'<span style="font-size:.6rem;background:rgba(255,77,109,.2);color:var(--red);padding:1px 5px;border-radius:3px;margin-left:4px">CRITICAL</span>':b.p>80?'<span style="font-size:.6rem;background:rgba(245,166,35,.2);color:var(--amber);padding:1px 5px;border-radius:3px;margin-left:4px">FULL</span>':'';
    const sensor=i===0?'<span style="font-size:.58rem;color:var(--teal);margin-left:4px">● Live</span>':'<span style="font-size:.58rem;color:var(--text-dim);margin-left:4px">○ Sim</span>';
    return `<div class="bi2"><div class="bi-hdr"><span class="bi-name">${b.n}${sensor}${badge}</span><span class="bi-pct" style="color:${col}">${b.p}%</span></div><div class="bin-bar"><div class="bin-fill bf-${b.cls}" style="width:${b.p}%"></div></div><div class="bi-loc">📍 ${b.loc}</div><div style="display:flex;gap:7px;margin-top:8px;flex-wrap:wrap"><button class="btn btn-success btn-sm" onclick="collectBin(${i})">🚛 Collect</button><button class="btn btn-outline btn-sm" onclick="addWaste(${i})">+ Add Waste</button></div></div>`;
  }).join('');
  setTxt('bins-critical',bins.filter(b=>b.p>80).length);
  setTxt('bins-ok',bins.filter(b=>b.p<=80).length);
  const ch=Chart.getChart&&Chart.getChart(document.getElementById('waste-chart'));
  if(ch){ch.data.datasets[0].data=bins.map(b=>b.p);ch.data.datasets[0].backgroundColor=bins.map(b=>({l:'rgba(29,233,155,.6)',m:'rgba(255,209,102,.6)',h:'rgba(245,166,35,.7)',c:'rgba(255,77,109,.8)'})[b.cls]);ch.update('none');}
}
async function collectBin(i){const k=['bin1','bin2'][i];await writeCmd('waste/'+k+'_collected',true);bins[i].p=0;bins[i].cls='l';renderBins();toast(`${bins[i].n} marked as collected`,'ok');}
function addWaste(i){bins[i].p=Math.min(100,bins[i].p+10);bins[i].cls=bins[i].p>90?'c':bins[i].p>70?'h':bins[i].p>50?'m':'l';renderBins();toast(`${bins[i].n}: +10%`,'info');}
window.collectBin=collectBin; window.addWaste=addWaste;

/* ── HOME PAGE ────────────────────────────────── */
function initHomePage(){
  mkChart('home-flow-chart','line',H24(),[{label:'Flow L/min',data:rnd(24,8,18),borderColor:'#00c8dc',backgroundColor:'rgba(0,200,220,.08)',tension:.4,fill:true,pointRadius:0}]);
  mkChart('home-modules','doughnut',['Water ✅','Weather ✅','Complaint ✅','Lights','Waste','Traffic','Park'],[{data:[100,100,100,65,75,60,100],backgroundColor:['rgba(0,200,220,.8)','rgba(167,139,250,.7)','rgba(29,233,155,.7)','rgba(255,209,102,.6)','rgba(245,166,35,.6)','rgba(255,77,109,.6)','rgba(29,233,155,.5)'],borderWidth:0}]);
}

/* ── ADMIN PAGE ───────────────────────────────── */

/* Local user storage helpers (Firebase listener also calls renderUserTableFromFb) */
const USERS_KEY = 'sc_users_local';
let usersCache = [];
function getUsers() {
  if (usersCache.length > 0) return usersCache;
  try { return JSON.parse(localStorage.getItem(USERS_KEY)) || []; }
  catch(e) { return []; }
}
function saveUsers(arr) {
  usersCache = arr;
  try { localStorage.setItem(USERS_KEY, JSON.stringify(arr)); } catch(e){}
}
/* Called by Firebase listener (firebase-config.js) */
function renderUserTableFromFb(list) {
  usersCache = list || [];
  saveUsers(usersCache);
  if (typeof renderUserTable === 'function') renderUserTable();
  if (typeof renderAdminStats === 'function') renderAdminStats();
}
window.renderUserTableFromFb = renderUserTableFromFb;

function initAdminPage(){
  if(!requireAdmin())return;
  renderUserTable();
  renderAdminStats();
}
function renderUserTable(){
  const tbody=document.getElementById('users-tbody');if(!tbody)return;
  const users=getUsers();
  tbody.innerHTML=users.map(u=>`<tr><td>${u.id}</td><td><strong>${u.name}</strong></td><td>${u.email}</td><td><span class="role-${u.role}">${u.role==='admin'?'⚡ Admin':'👤 User'}</span></td><td>${u.city}</td><td>${u.joined}</td><td><div style="display:flex;gap:6px;"><button class="btn btn-outline btn-sm" onclick="toggleUserRole(${u.id})">${u.role==='admin'?'→ User':'→ Admin'}</button><button class="btn btn-danger btn-sm" onclick="deleteUser(${u.id})">Delete</button></div></td></tr>`).join('');
}
function renderAdminStats(){
  const users=getUsers();const c=getComplaints();
  setTxt('admin-total-users',users.length);
  setTxt('admin-total-admins',users.filter(u=>u.role==='admin').length);
  setTxt('admin-total-complaints',c.length);
  setTxt('admin-open-complaints',c.filter(x=>x.status==='open').length);
}
function toggleUserRole(id){
  const users=getUsers();const i=users.findIndex(u=>u.id===id);
  if(i>-1){users[i].role=users[i].role==='admin'?'user':'admin';saveUsers(users);renderUserTable();toast(`User role updated`,'ok');}
}
function deleteUser(id){
  const s=getSession();if(s&&s.id===id){toast('Cannot delete yourself!','err');return;}
  if(!confirm('Delete this user?'))return;
  saveUsers(getUsers().filter(u=>u.id!==id));renderUserTable();toast('User deleted','info');
}
window.toggleUserRole=toggleUserRole; window.deleteUser=deleteUser;

/* ── SURVEILLANCE ─────────────────────────────── */
function initSurveillancePage(){
  mkChart('motion-chart','bar',['6am','8am','10am','12pm','2pm','4pm','6pm','8pm','10pm'],[{label:'Motion Events',data:[2,8,5,3,4,7,12,15,6],backgroundColor:'rgba(167,139,250,.65)',borderRadius:5}]);
}

/* ── HOME PAGE ────────────────────────────────── */
function initHomePage(){
  mkChart('home-flow-chart','line',H24(),[{label:'Flow L/min',data:rnd(24,8,18),borderColor:'#00c8dc',backgroundColor:'rgba(0,200,220,.08)',tension:.4,fill:true,pointRadius:0}]);
  mkChart('home-modules','doughnut',['Water ✅','Weather ✅','Complaint ✅','Lights','Waste','Traffic','Park'],[{data:[100,100,100,65,75,60,100],backgroundColor:['rgba(0,200,220,.8)','rgba(167,139,250,.7)','rgba(29,233,155,.7)','rgba(255,209,102,.6)','rgba(245,166,35,.6)','rgba(255,77,109,.6)','rgba(29,233,155,.5)'],borderWidth:0}]);
}

/* ── ADMIN PAGE ───────────────────────────────── */
function initAdminPage(){
  if(!requireAdmin())return;
  const s=getSession();
  const nm=document.getElementById('admin-name');if(nm)nm.textContent=s.name;
  const fbSt=document.getElementById('admin-fb-status');if(fbSt){fbSt.textContent=fbConnected?'Connected':'Offline';fbSt.className=fbConnected?'dv g':'dv a';}
  renderUserTable();
  renderAdminStats();
  // Load complaints
  if(fbConnected){
    // Firebase listener will call updateAdminComplaintFeed
  } else {
    renderAdminComplaints(getComplaints());
  }
}

function renderAdminComplaints(list){
  const tbody=document.getElementById('admin-complaints-tbody');if(!tbody)return;
  if(!list||!list.length){tbody.innerHTML='<tr><td colspan="7" style="text-align:center;color:var(--text-dim);padding:20px;">No complaints yet</td></tr>';renderAdminStats(list);return;}
  tbody.innerHTML=list.map(c=>`
    <tr>
      <td style="font-size:.7rem;color:var(--text-dim);">#${c.id||c.fbKey?.slice(-4)||'—'}</td>
      <td><strong>${c.title}</strong><br><span style="font-size:.65rem;color:var(--text-dim);">${c.cat}</span></td>
      <td><span style="font-size:.7rem;color:var(--text-dim);">👤 ${c.user}</span></td>
      <td>📍 ${c.loc}</td>
      <td><span class="pri-badge pri-${c.priority}">${c.priority}</span></td>
      <td><span class="cb ${c.status==='open'?'op':c.status==='progress'?'pr':'rs'}">${c.status==='open'?'Open':c.status==='progress'?'In Progress':'Resolved'}</span></td>
      <td>
        <div style="display:flex;gap:5px;flex-wrap:wrap;">
          ${c.status!=='progress'?`<button class="btn btn-outline btn-sm" onclick="adminUpdateC('${c.fbKey||c.id}','progress',${!c.fbKey})">🔵</button>`:''}
          ${c.status!=='resolved'?`<button class="btn btn-success btn-sm" onclick="adminUpdateC('${c.fbKey||c.id}','resolved',${!c.fbKey})">✅</button>`:''}
          <button class="btn btn-danger btn-sm" onclick="adminDeleteC('${c.fbKey||c.id}',${!c.fbKey})">🗑</button>
        </div>
      </td>
    </tr>`).join('');
  renderAdminStats(list);
}
async function adminUpdateC(id,status,isLocal){await updateCStatus(id,status,isLocal);if(!fbConnected){renderAdminComplaints(getComplaints());}}
async function adminDeleteC(id,isLocal){await deleteCById(id,isLocal);if(!fbConnected){renderAdminComplaints(getComplaints());}}
window.adminUpdateC=adminUpdateC; window.adminDeleteC=adminDeleteC;

function renderUserTable(){
  const tbody=document.getElementById('users-tbody');if(!tbody)return;
  const users=getUsers();
  tbody.innerHTML=users.map(u=>`<tr>
    <td style="font-size:.68rem;color:var(--text-dim);">${String(u.id).slice(-6)}</td>
    <td><strong>${u.name}</strong></td>
    <td style="font-size:.72rem;">${u.email}</td>
    <td><span class="role-${u.role}">${u.role==='admin'?'⚡ Admin':'👤 User'}</span></td>
    <td>${u.city}</td>
    <td>${u.joined}</td>
    <td><div style="display:flex;gap:6px;">
      <button class="btn btn-outline btn-sm" onclick="toggleUserRole('${u.id}')">${u.role==='admin'?'→ User':'→ Admin'}</button>
      <button class="btn btn-danger btn-sm" onclick="deleteUser('${u.id}')">Delete</button>
    </div></td>
  </tr>`).join('');
}
function renderAdminStats(list){
  const users=getUsers();
  const c=list||(fbConnected?allComplaintsCache:getComplaints());
  setTxt('admin-total-users',users.length);
  setTxt('admin-total-admins',users.filter(u=>u.role==='admin').length);
  setTxt('admin-total-complaints',c.length);
  setTxt('admin-open-complaints',c.filter(x=>x.status==='open').length);
}
function toggleUserRole(id){
  const users=getUsers();const i=users.findIndex(u=>u.id==id||u.id===id);
  if(i>-1){users[i].role=users[i].role==='admin'?'user':'admin';saveUsers(users);renderUserTable();toast('User role updated','ok');}
}
function deleteUser(id){
  const s=getSession();if(s&&(s.id===id||s.id==id)){toast('Cannot delete yourself!','err');return;}
  if(!confirm('Delete this user?'))return;
  saveUsers(getUsers().filter(u=>u.id!=id&&u.id!==id));renderUserTable();toast('User deleted','info');
}
window.toggleUserRole=toggleUserRole; window.deleteUser=deleteUser;

/* ── ADD USER MODAL ──────────────────────────── */
function showAddUserModal(){
  const m=document.getElementById('add-user-modal');if(m)m.classList.remove('hidden');
}
window.showAddUserModal=showAddUserModal;
async function addUserFromModal(){
  const name=val('nu-name'),email=val('nu-email'),pass=document.getElementById('nu-pass')?.value||'',role=val('nu-role'),city=val('nu-city')||'Faisalabad';
  if(!name||!email||!pass){toast('Fill all fields','err');return;}
  const res=await doSignup(name,email,pass,role,city);
  if(!res.ok){toast(res.msg,'err');return;}
  // Restore current session (doSignup saves new user session)
  const currentSession=getSession();
  renderUserTable();
  toast(`✅ User ${name} added`,'ok');
  const m=document.getElementById('add-user-modal');if(m)m.classList.add('hidden');
}
window.addUserFromModal=addUserFromModal;

/* ── SURVEILLANCE ─────────────────────────────── */
function initSurveillancePage(){
  mkChart('motion-chart','bar',['6am','8am','10am','12pm','2pm','4pm','6pm','8pm','10pm'],[{label:'Motion Events',data:[2,8,5,3,4,7,12,15,6],backgroundColor:'rgba(167,139,250,.65)',borderRadius:5}]);
}

/* ── AUTO INIT ────────────────────────────────── */
document.addEventListener('DOMContentLoaded',()=>{
  initTheme();
  renderTopbarUser();
  renderStatusDots();
  setInterval(updateStatusDots, 5000);
  if(typeof firebase!=='undefined') initFirebase();
  if(!fbConnected&&typeof waterState!=='undefined'){
    Object.assign(waterState,DEMO.water,{flow:DEMO.water.flow_rate,total:DEMO.water.total_liters});
  }
  if(!fbConnected&&typeof wthState!=='undefined'){
    wthState.temp=DEMO.weather.temperature;
    wthState.hum=DEMO.weather.humidity;
    wthState.feels=DEMO.weather.feels_like||wthState.temp;
    wthState.dew=DEMO.weather.dew_point||19.3;
  }
  const p=window.location.pathname.split('/').pop().replace('.html','')||'index';
  const init={index:initHomePage,water:initWaterPage,weather:initWeatherPage,park:initParkPage,traffic:initTrafficPage,street:initStreetPage,waste:initWastePage,complain:initComplaintPage,admin:initAdminPage,surveillance:initSurveillancePage};
  if(init[p]) init[p]();
  const tt=document.getElementById('theme-toggle-btn');
  if(tt) tt.addEventListener('click',toggleTheme);
});
window.addEventListener('pagehide',()=>{
  if(waterState?.timer) clearInterval(waterState.timer);
  if(parkState?.timer)  clearInterval(parkState.timer);
  if(typeof tlTimer!=='undefined'&&tlTimer) clearInterval(tlTimer);
});


/* ── PAGE BUILDERS (called from individual pages) ── */
function buildPage_park(){
  const root=document.getElementById('park-root');if(!root)return;
  root.innerHTML=`
  <div class="alert warn" id="park-alert-bar" style="display:none"><span>⚠️</span>&nbsp;<span id="park-alert-msg">Zone dry — Pump auto-activated!</span></div>
  <div class="stat-grid">
    <div class="sc t"><div class="si">🌱</div><div class="sl">Active Zones</div><div class="sv">2</div></div>
    <div class="sc g"><div class="si">💧</div><div class="sl">Water Today</div><div class="sv" id="park-water-total">0 L</div></div>
    <div class="sc r"><div class="si">🏜️</div><div class="sl">Dry Zones</div><div class="sv" id="park-dry-zones">0</div></div>
    <div class="sc a"><div class="si">⚙️</div><div class="sl">Mode</div><div class="sv" id="park-auto-status">AUTO</div></div>
  </div>
  <div class="card mt"><div class="ct">🎛️ Master Controls</div>
    <div class="btn-row">
      <button class="btn btn-success btn-lg" id="btn-pump-all-on">▶ All Pumps ON</button>
      <button class="btn btn-danger btn-lg" id="btn-pump-all-off">⏹ All Pumps OFF</button>
      <button class="btn btn-amber" id="btn-park-auto">🤖 Toggle Auto Mode</button>
      <button class="btn btn-outline" id="btn-water-reset">🔄 Reset Total</button>
    </div>
  </div>
  <div class="g2 mt">
    <div class="card"><div class="ct">🌿 Zone Moisture &amp; Pump Control</div>
      <div class="soil-grid" id="soil-grid"></div>
      <div class="pump-box" id="pump-box"><div class="pump-icon">⚙️</div>
        <div><div class="pump-state" id="pump-state">○ All pumps idle</div>
        <div style="font-size:.65rem;color:var(--text-dim)" id="park-sensor-status">Waiting for sensor data…</div></div>
      </div>
    </div>
    <div class="card"><div class="ct">📈 Moisture Trend</div><div class="cw tall"><canvas id="moisture-chart"></canvas></div></div>
  </div>
  <div class="g2 mt">
    <div class="card"><div class="ct">💦 Daily Water Use (L)</div><div class="cw"><canvas id="park-water"></canvas></div></div>
    <div class="card"><div class="ct">⚙️ System</div><div class="dr-list">
      <div class="di"><span class="dk">Sensors</span><span class="dv">Soil Moisture × 2</span></div>
      <div class="di"><span class="dk">Controller</span><span class="dv">Arduino UNO → ESP8266</span></div>
      <div class="di"><span class="dk">Auto ON</span><span class="dv">Moisture &lt; 30%</span></div>
      <div class="di"><span class="dk">Auto OFF</span><span class="dv">Moisture &gt; 75%</span></div>
      <div class="di"><span class="dk">Zone A/B</span><span class="dv g" id="park-sensor-status2">Live sensor</span></div>
    </div></div>
  </div>`;
  initParkPage();
}

function buildPage_traffic(){
  const root=document.getElementById('traffic-root');if(!root)return;
  root.innerHTML=`
  <div class="alert err" id="traffic-alert-bar" style="display:none"><span>🚨</span>&nbsp;<span id="traffic-alert-msg">High density detected</span></div>
  <div class="stat-grid">
    <div class="sc t"><div class="si">🚗</div><div class="sl">Lane A (/min)</div><div class="sv" id="traffic-lane-a-count" style="font-size:1.1rem;">—</div></div>
    <div class="sc g"><div class="si">🚙</div><div class="sl">Lane B (/min)</div><div class="sv" id="traffic-lane-b-count" style="font-size:1.1rem;">—</div></div>
    <div class="sc a"><div class="si">🚦</div><div class="sl">Active Signal</div><div class="sv" id="traffic-signal-state" style="font-size:1rem;">—</div></div>
    <div class="sc p"><div class="si">📊</div><div class="sl">Total Today</div><div class="sv" id="traffic-total-count" style="font-size:1.1rem;">—</div></div>
  </div>
  <div class="card mt"><div class="ct">🎛️ Mode &amp; Auto Control</div>
    <div class="btn-row"><button class="btn btn-primary btn-lg" id="btn-tl-auto">🔄 Auto: ON</button></div>
    <div style="font-size:.7rem;color:var(--text-dim);margin-top:6px;">Auto mode: Signal timing density-based on both lanes</div>
  </div>
  <div class="card mt"><div class="ct">🚦 Manual Signal Override</div>
    <div class="btn-row">
      <button class="btn btn-success" id="btn-force-green-a">🟢 Green Lane A</button>
      <button class="btn btn-outline" id="btn-force-green-b">🟢 Green Lane B</button>
      <button class="btn btn-danger" id="btn-force-red-all">🔴 All Red</button>
    </div>
  </div>
  <div class="card mt"><div class="ct">🚨 Emergency Override</div>
    <div class="btn-row">
      <button class="btn btn-amber" id="btn-emergency-a">🚨 Emergency — Open Lane A (5 min)</button>
      <button class="btn btn-amber" id="btn-emergency-b">🚨 Emergency — Open Lane B (5 min)</button>
    </div>
  </div>
  <div class="g2 mt">
    <div class="card"><div class="ct">🚦 Live Signal Status</div><div class="tl-row" id="tl-row"></div></div>
    <div class="card"><div class="ct">📊 Vehicle Count — Both Lanes</div><div class="cw"><canvas id="traffic-chart"></canvas></div></div>
  </div>
  <div class="g2 mt">
    <div class="card"><div class="ct">📡 Lane Status</div><div class="dr-list">
      <div class="di"><span class="dk">Lane A Status</span><span class="dv" id="traffic-lane-a-status">—</span></div>
      <div class="di"><span class="dk">Lane A Count Today</span><span class="dv" id="traffic-lane-a-today">—</span></div>
      <div class="di"><span class="dk">Lane B Status</span><span class="dv" id="traffic-lane-b-status">—</span></div>
      <div class="di"><span class="dk">Lane B Count Today</span><span class="dv" id="traffic-lane-b-today">—</span></div>
    </div></div>
    <div class="card"><div class="ct">⚙️ System</div><div class="dr-list">
      <div class="di"><span class="dk">Sensors</span><span class="dv">2× HC-SR04 (Lane A + B)</span></div>
      <div class="di"><span class="dk">Controller</span><span class="dv">Arduino UNO + ESP8266</span></div>
      <div class="di"><span class="dk">Auto Mode</span><span class="dv g">Density-based (both lanes)</span></div>
      <div class="di"><span class="dk">Signal Info</span><span class="dv" id="traffic-signal-duration">Awaiting data…</span></div>
    </div></div>
  </div>`;
  initTrafficPage();
}

function buildPage_street(){
  const root=document.getElementById('street-root');if(!root)return;
  root.innerHTML=`
  <div class="stat-grid">
    <div class="sc t"><div class="si">💡</div><div class="sl">Lights ON</div><div class="sv" id="lights-on-count">—</div></div>
    <div class="sc g"><div class="si">🌓</div><div class="sl">Mode</div><div class="sv" id="street-mode-val" style="font-size:1rem;">—</div></div>
    <div class="sc a"><div class="si">☀️</div><div class="sl">LDR Value</div><div class="sv" id="street-lux-val" style="font-size:1rem;">—</div></div>
    <div class="sc p"><div class="si">🏃</div><div class="sl">Motion</div><div class="sv" id="street-motion-val" style="font-size:1rem;">—</div></div>
  </div>
  <div class="card mt"><div class="ct">🎛️ Light Control — Current Mode: <span id="street-current-mode" style="color:var(--teal);font-weight:500">AUTO (LDR+PIR)</span></div>
    <div class="btn-row">
      <button class="btn btn-success btn-lg" id="btn-all-on">💡 Force ALL ON</button>
      <button class="btn btn-danger btn-lg" id="btn-all-off">🌑 Force ALL OFF</button>
      <button class="btn btn-amber btn-lg" id="btn-auto-all">🤖 AUTO Mode</button>
    </div>
    <div class="dr-list" style="margin-top:10px">
      <div class="di"><span class="dk">Force ON</span><span class="dv">Lights stay ON — ignores sensors</span></div>
      <div class="di"><span class="dk">Force OFF</span><span class="dv">Lights stay OFF — ignores sensors</span></div>
      <div class="di"><span class="dk">AUTO</span><span class="dv g">Dark + Motion → ON · Day/No Motion → OFF</span></div>
    </div>
  </div>
  <div class="g2 mt">
    <div class="card"><div class="ct">💡 Zone Status (Zone A-1 = Live Sensor)</div><div class="lg-grid" id="lg-grid"></div></div>
    <div class="card"><div class="ct">⚡ Energy — 12h (kWh)</div><div class="cw"><canvas id="energy-chart"></canvas></div></div>
  </div>
  <div class="g2 mt">
    <div class="card"><div class="ct">🌙 Brightness History</div><div class="cw"><canvas id="brightness-chart"></canvas></div></div>
    <div class="card"><div class="ct">⚙️ AUTO Logic</div><div class="dr-list">
      <div class="di"><span class="dk">Day (LDR high)</span><span class="dv g">Lights OFF automatically</span></div>
      <div class="di"><span class="dk">Night + Motion</span><span class="dv g">Lights ON (100%)</span></div>
      <div class="di"><span class="dk">Night, No Motion</span><span class="dv a">Lights OFF (energy save)</span></div>
      <div class="di"><span class="dk">LDR threshold</span><span class="dv">Below 400 = Night</span></div>
    </div></div>
  </div>`;
  initStreetPage();
}

function buildPage_waste(){
  const root=document.getElementById('waste-root');if(!root)return;
  root.innerHTML=`
  <div class="alert err" id="waste-alert-critical" style="display:none"><span>🚨</span>&nbsp;<span id="waste-alert-critical-msg">Bin critical — Collect now!</span></div>
  <div class="alert warn" id="waste-alert-warn" style="display:none"><span>⚠️</span>&nbsp;<span id="waste-alert-warn-msg">Bin filling up — Schedule soon.</span></div>
  <div class="stat-grid">
    <div class="sc t"><div class="si">🗑️</div><div class="sl">Active Bins</div><div class="sv">2</div></div>
    <div class="sc r"><div class="si">🚨</div><div class="sl">Critical (&gt;90%)</div><div class="sv" id="bins-critical">0</div></div>
    <div class="sc g"><div class="si">✅</div><div class="sl">OK</div><div class="sv" id="bins-ok">2</div></div>
    <div class="sc a"><div class="si">🛣️</div><div class="sl">Route</div><div class="sv" id="waste-route-badge">Idle</div></div>
  </div>
  <div class="card mt"><div class="ct">🎛️ Collection Management</div>
    <div class="btn-row">
      <button class="btn btn-success btn-lg" id="btn-collect-all">🚛 Mark All Collected</button>
      <button class="btn btn-amber" id="btn-collect-critical">🚨 Collect Critical Only</button>
      <button class="btn btn-primary" id="btn-gen-route">🗺️ Generate Route</button>
    </div>
    <div style="margin-top:10px;font-size:.78rem;color:var(--text-dim);padding:8px 10px;background:var(--surface2);border-radius:6px" id="waste-route-status">No active route — press Generate Route to create one</div>
  </div>
  <div class="g64 mt">
    <div class="card"><div class="ct">📊 Fill Levels</div><div class="cw tall"><canvas id="waste-chart"></canvas></div></div>
    <div class="card"><div class="ct">🗑️ Bin Status</div><div class="bin-list" id="bin-list"></div></div>
  </div>
  <div class="g2 mt">
    <div class="card"><div class="ct">📈 Weekly Fill Trend</div><div class="cw"><canvas id="waste-trend"></canvas></div></div>
    <div class="card"><div class="ct">⚙️ System</div><div class="dr-list">
      <div class="di"><span class="dk">Bin 1</span><span class="dv g" id="waste-bin1-live">● Live Sensor (HC-SR04)</span></div>
      <div class="di"><span class="dk">Bin 2</span><span class="dv a">○ Simulation</span></div>
      <div class="di"><span class="dk">Alert</span><span class="dv a">&gt; 80%</span></div>
      <div class="di"><span class="dk">Critical</span><span class="dv r">&gt; 90%</span></div>
      <div class="di"><span class="dk">Protocol</span><span class="dv">ESP8266 → Firebase</span></div>
    </div></div>
  </div>`;
  initWastePage();
}
