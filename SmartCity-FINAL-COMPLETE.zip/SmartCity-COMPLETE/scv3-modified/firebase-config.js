// ═══════════════════════════════════════════════════
//  firebase-config.js — Smart City v5.1 (FULL CONTROL)
//  Updated: All modules with bidirectional Firebase sync
// ═══════════════════════════════════════════════════

const firebaseConfig = {
  apiKey:            "YOUR_API_KEY",
  authDomain:        "YOUR_PROJECT.firebaseapp.com",
  databaseURL:       "https://smart-city-tuf-default-rtdb.firebaseio.com",
  projectId:         "YOUR_PROJECT",
  storageBucket:     "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId:             "YOUR_APP_ID"
};

// ── DATABASE PATHS ────────────────────────────────
const DB = {
  water:          'sensors/water',
  weather:        'sensors/weather',
  traffic:        'sensors/traffic',
  waste:          'sensors/waste',
  street:         'sensors/street',
  park:           'sensors/park',
  commands:       'commands',
  complaints:     'complaints',
  users:          'users',
  system:         'system',
  signupRequests: 'signupRequests',
};

let db            = null;
let fbAuth        = null;
let fbConnected   = false;
let currentFbUser = null;

// ── WRITE COMMAND TO FIREBASE ─────────────────────
async function writeCmd(path, value) {
  if (!db || !fbConnected) { toast('Firebase not connected','err'); return false; }
  try { await db.ref(DB.commands + '/' + path).set(value); return true; }
  catch(e) { toast('Command failed: ' + e.message,'err'); console.error(e); return false; }
}

// ════════════════════════════════════════════════
//  SEED ADMIN DATA
// ════════════════════════════════════════════════
async function seedFirebaseData() {
  if (!db) return;
  const defaultUsers = [
    { id:'admin-001', name:'M Faizan Nasir', phone:'03001234567', houseNo:'12-A', block:'Block B', email:'faizan@smartcity.pk', password:'faizan123', role:'admin', city:'Faisalabad', joined:'Apr 2026' },
    { id:'admin-002', name:'M Saad Zubair',  phone:'03009876543', houseNo:'45',   block:'Block C', email:'saad@smartcity.pk',   password:'saad123',   role:'admin', city:'Faisalabad', joined:'Apr 2026' },
    { id:'user-001',  name:'Ahmed Khan',     phone:'03011111111', houseNo:'5',    block:'Block A', email:'ahmed@citizen.pk',    role:'user', city:'Faisalabad', joined:'Apr 2026' },
    { id:'user-002',  name:'Sara Ali',       phone:'03022222222', houseNo:'8-B',  block:'Block D', email:'sara@citizen.pk',     role:'user', city:'Faisalabad', joined:'Apr 2026' },
    { id:'user-003',  name:'Bilal Hussain',  phone:'03033333333', houseNo:'22',   block:'Block A', email:'bilal@citizen.pk',    role:'user', city:'Faisalabad', joined:'Apr 2026' },
  ];
  try {
    const snap = await db.ref(DB.users).once('value');
    const existing = snap.val() || {};
    const updates = {};
    for (const u of defaultUsers) {
      if (!existing[u.id]) {
        updates[DB.users + '/' + u.id] = {
          name:u.name, phone:u.phone, houseNo:u.houseNo, block:u.block,
          email:u.email, role:u.role, city:u.city, joined:u.joined,
          createdAt:Date.now(), ...(u.password?{password:u.password}:{})
        };
      }
    }
    if (Object.keys(updates).length > 0) {
      await db.ref().update(updates);
      console.log('✅ Firebase seeded');
    }
  } catch(e) { console.warn('Seed error:', e.message); }
}

// ── INITIALIZE DEFAULT COMMANDS ───────────────────
function initializeCommands() {
  if (!db) return;
  db.ref(DB.commands).once('value').then(snap => {
    if (snap.val()) return;
    db.ref(DB.commands).set({
      street:  { mode: 'auto' },
      traffic: { mode: 'auto', signal: 'none' },
      park:    { mode: 'auto', zone_a_pump: false, zone_b_pump: false },
      waste:   { bin1_collected: false, bin2_collected: false, route_active: false }
    });
    console.log('[Commands] Defaults initialized');
  });
}

// ════════════════════════════════════════════════
//  FIREBASE INIT
// ════════════════════════════════════════════════
function initFirebase() {
  try {
    if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
    if (firebaseConfig.apiKey === 'YOUR_API_KEY') {
      fbConnected = false;
      updateFbBar(false, 'Add your Firebase config in firebase-config.js');
      return false;
    }
    db     = firebase.database();
    fbAuth = firebase.auth();
    fbConnected = true;
    updateFbBar(true);
    seedFirebaseData();
    initializeCommands();

    fbAuth.onAuthStateChanged(user => {
      currentFbUser = user;
      if (user) {
        db.ref(DB.users + '/' + user.uid).once('value').then(snap => {
          const data = snap.val() || {};
          const session = {
            id:user.uid, name:data.name||user.email.split('@')[0], email:user.email,
            role:data.role||'user', phone:data.phone||'', houseNo:data.houseNo||'',
            block:data.block||'', city:data.city||'Faisalabad',
            avatar:(data.name||user.email)[0].toUpperCase()
          };
          saveSession(session);
          renderTopbarUser();
        });
      }
    });

    const p = getCurrentPage();
    if (p === 'water')    startWaterListener();
    if (p === 'weather')  startWeatherListener();
    if (p === 'traffic')  startTrafficListener();
    if (p === 'waste')    startWasteListener();
    if (p === 'street')   startStreetListener();
    if (p === 'park')     startParkListener();
    if (p === 'index')    {
      // Dashboard — listen to ALL sensors for live module card data
      startWaterListener();
      startWeatherListener();
      startComplaintsListener();
      startStreetListener();
      startWasteListener();
      startTrafficListener();
      startParkListener();
    }
    if (p === 'complain') startComplaintsListener();
    if (p === 'admin')    { startComplaintsListener(); startUsersListener(); startSignupRequestsListener(); }
    return true;
  } catch(e) {
    fbConnected = false;
    updateFbBar(false, e.message);
    return false;
  }
}

function getCurrentPage() {
  return window.location.pathname.split('/').pop().replace('.html','') || 'index';
}

function updateFbBar(ok, msg='') {
  const bar = document.getElementById('fb-status-bar'); if (!bar) return;
  bar.innerHTML = ok
    ? `🔥 Firebase Connected · Realtime DB active <span class="dot dg" style="margin-left:8px"></span>`
    : `⚪ Offline — ${msg||'Add Firebase config'} <span class="dot" style="margin-left:8px;background:var(--text-dim)"></span>`;
  bar.style.color = ok ? 'var(--green)' : 'var(--text-dim)';
}

// ════════════════════════════════════════════════
//  AUTH FUNCTIONS
// ════════════════════════════════════════════════
async function fbSignin(email, password) {
  if (!fbAuth) return { ok:false, msg:'Firebase not configured' };
  try {
    const cred = await fbAuth.signInWithEmailAndPassword(email, password);
    const uid  = cred.user.uid;
    const snap = await db.ref(DB.users + '/' + uid).once('value');
    const data = snap.val() || {};
    const session = {
      id:uid, name:data.name||email.split('@')[0], email:cred.user.email,
      role:data.role||'user', phone:data.phone||'', houseNo:data.houseNo||'',
      block:data.block||'', city:data.city||'Faisalabad',
      avatar:(data.name||email)[0].toUpperCase()
    };
    saveSession(session);
    return { ok:true, user:session };
  } catch(e) { return { ok:false, msg:fbAuthError(e.code) }; }
}

async function fbSignout() {
  if (fbAuth) await fbAuth.signOut().catch(()=>{});
  clearSession();
  window.location.href = 'login.html';
}

async function fbResetPassword(email) {
  if (!fbAuth) return { ok:false, msg:'Firebase not configured' };
  try {
    await fbAuth.sendPasswordResetEmail(email);
    return { ok:true, msg:'Password reset email sent!' };
  } catch(e) { return { ok:false, msg:fbAuthError(e.code) }; }
}

async function fbPhoneSignin(name, phone, houseNo, block) {
  if (!db) return { ok:false, msg:'Firebase not configured' };
  try {
    const reqSnap = await db.ref(DB.signupRequests).orderByChild('phone').equalTo(phone).once('value');
    if (reqSnap.val()) {
      const reqs = Object.values(reqSnap.val());
      const pending = reqs.find(r => r.status === 'pending');
      const denied  = reqs.find(r => r.status === 'denied');
      if (pending) return { ok:false, msg:'⏳ Your account is pending admin approval. Please wait.' };
      if (denied)  return { ok:false, msg:'❌ Your account request was denied. Contact city administration.' };
    }
    const snap = await db.ref(DB.users).orderByChild('phone').equalTo(phone).once('value');
    const data = snap.val();
    if (!data) return { ok:false, msg:'Phone number not registered. Please sign up or contact city administration.' };
    const uid  = Object.keys(data)[0];
    const user = data[uid];
    if (user.role === 'admin') return { ok:false, msg:'Use Admin Login tab for admin accounts.' };
    await db.ref(DB.users + '/' + uid).update({ name:name||user.name, houseNo:houseNo||user.houseNo, block:block||user.block });
    const session = {
      id:uid, name:name||user.name, email:user.email||phone+'@citizen.local',
      role:'user', phone, houseNo:houseNo||user.houseNo, block:block||user.block,
      city:user.city||'Faisalabad', avatar:(name||user.name)[0].toUpperCase()
    };
    saveSession(session);
    return { ok:true, user:session };
  } catch(e) { return { ok:false, msg:'Error: ' + e.message }; }
}

async function fbPhoneSignup(name, phone, houseNo, block, city) {
  if (!db) return { ok:false, msg:'Firebase not configured' };
  try {
    const userSnap = await db.ref(DB.users).orderByChild('phone').equalTo(phone).once('value');
    if (userSnap.val()) return { ok:false, msg:'This phone number is already registered. Please sign in.' };
    const reqSnap = await db.ref(DB.signupRequests).orderByChild('phone').equalTo(phone).once('value');
    if (reqSnap.val()) {
      const reqs = Object.values(reqSnap.val());
      if (reqs.find(r => r.status === 'pending')) return { ok:false, msg:'Your signup request is already pending. Please wait for admin approval.' };
      if (reqs.find(r => r.status === 'denied'))  return { ok:false, msg:'Your previous request was denied. Contact city administration.' };
    }
    await db.ref(DB.signupRequests).push({
      name: name.trim(), phone,
      houseNo: houseNo || '—', block: block || '—',
      city: city || 'Faisalabad', status: 'pending', createdAt: Date.now()
    });
    return { ok:true, pending:true };
  } catch(e) { return { ok:false, msg:'Error: ' + e.message }; }
}

function fbAuthError(code) {
  const map = {
    'auth/user-not-found':'No account found with this email','auth/wrong-password':'Incorrect password',
    'auth/email-already-in-use':'Email already registered','auth/weak-password':'Password too weak (min 6 chars)',
    'auth/invalid-email':'Invalid email address','auth/too-many-requests':'Too many attempts. Try again later.',
    'auth/network-request-failed':'Network error. Check connection.','auth/invalid-credential':'Invalid email or password',
  };
  return map[code] || 'Auth error: ' + code;
}

// ════════════════════════════════════════════════
//  USERS LISTENER
// ════════════════════════════════════════════════
function startUsersListener() {
  if (!db) return;
  db.ref(DB.users).on('value', snap => {
    const data = snap.val() || {};
    const list = Object.entries(data).map(([uid, u]) => ({...u, id:uid}));
    if (typeof renderUserTableFromFb === 'function') renderUserTableFromFb(list);
  });
}

// ════════════════════════════════════════════════
//  SIGNUP REQUESTS LISTENER
// ════════════════════════════════════════════════
function startSignupRequestsListener() {
  if (!db) return;
  db.ref(DB.signupRequests).orderByChild('createdAt').on('value', snap => {
    const data = snap.val() || {};
    const list = Object.entries(data).map(([k,v]) => ({...v, reqKey:k})).sort((a,b) => (b.createdAt||0) - (a.createdAt||0));
    const pendingCount = list.filter(r => r.status === 'pending').length;
    document.querySelectorAll('.signup-req-badge').forEach(el => {
      el.textContent = pendingCount;
      el.style.display = pendingCount > 0 ? 'inline-flex' : 'none';
    });
    const notifBar = document.getElementById('signup-notif-bar');
    if (notifBar) notifBar.style.display = pendingCount > 0 ? 'flex' : 'none';
    const notifSub = document.getElementById('notif-sub-text');
    if (notifSub && pendingCount > 0) notifSub.textContent = `${pendingCount} citizen(s) are waiting for your approval`;
    if (typeof renderSignupRequests === 'function') renderSignupRequests(list);
  });
}

async function fbApproveSignupRequest(reqKey, userData) {
  if (!db) return;
  const uid = 'citizen-' + Date.now();
  await db.ref(DB.users + '/' + uid).set({
    name:userData.name, phone:userData.phone, houseNo:userData.houseNo||'—',
    block:userData.block||'—', email:userData.phone+'@citizen.local',
    role:'user', city:userData.city||'Faisalabad',
    joined:new Date().toLocaleDateString('en-PK',{month:'short',year:'numeric'}),
    createdAt:Date.now()
  });
  await db.ref(DB.signupRequests + '/' + reqKey).update({ status:'approved', reviewedAt:Date.now() });
}

async function fbDenySignupRequest(reqKey) {
  if (!db) return;
  await db.ref(DB.signupRequests + '/' + reqKey).update({ status:'denied', reviewedAt:Date.now() });
}

// ════════════════════════════════════════════════
//  WATER LISTENER
// ════════════════════════════════════════════════
function startWaterListener() {
  if (!db) return;
  db.ref(DB.water).on('value', snap => {
    const d = snap.val(); if (!d) return;
    const flow = parseFloat(d.flow_rate || 0);
    if (typeof waterState !== 'undefined') {
      waterState.flow   = flow.toFixed(1)*1;
      waterState.total  = parseFloat(d.total_liters ?? waterState.total).toFixed(0)*1;
      waterState.status = d.status ?? waterState.status;
      if (typeof renderWaterUI === 'function') renderWaterUI();
    }
    const hf = document.getElementById('home-flow-val');
    if (hf) hf.textContent = flow.toFixed(1);
    // Dashboard module card
    const mcFlow = document.getElementById('mc-flow');
    if (mcFlow) mcFlow.textContent = flow.toFixed(1) + ' L/min';

    // Live charts
    if (typeof pushChartLive === 'function') {
      pushChartLive('water-chart', flow);
      pushChartLive('home-flow-chart', flow);
    }
  });
}

// ════════════════════════════════════════════════
//  WEATHER LISTENER
// ════════════════════════════════════════════════
function startWeatherListener() {
  if (!db) return;
  db.ref(DB.weather).on('value', snap => {
    const d = snap.val(); if (!d) return;
    const temp = parseFloat(d.temperature || 0);
    const hum  = parseFloat(d.humidity    || 0);

    if (typeof wthState !== 'undefined') {
      if (d.temperature !== undefined) wthState.temp  = temp.toFixed(1)*1;
      if (d.humidity    !== undefined) wthState.hum   = hum.toFixed(1)*1;
      if (d.feels_like  !== undefined && d.feels_like > -50) wthState.feels = parseFloat(d.feels_like).toFixed(1)*1;
      if (d.dew_point   !== undefined) wthState.dew   = parseFloat(d.dew_point).toFixed(1)*1;
      if (typeof renderDHT22UI === 'function') renderDHT22UI();
    }
    const ht = document.getElementById('home-temp-val'); if(ht) ht.textContent = `${temp.toFixed(1)}°C`;
    const hh = document.getElementById('home-hum-val');  if(hh) hh.textContent = `${hum.toFixed(0)}%`;
    // Dashboard module card
    const mcTemp = document.getElementById('mc-temp');
    if (mcTemp) mcTemp.textContent = `${temp.toFixed(1)}°C · ${hum.toFixed(0)}%`;

    // Live charts
    if (typeof pushChartLive === 'function') {
      pushChartLive('temp-chart',  temp);
      pushChartLive('humid-chart', hum);
    }
  });
}

// ════════════════════════════════════════════════
//  TRAFFIC LISTENER
// ════════════════════════════════════════════════
function startTrafficListener() {
  if (!db) return;
  db.ref(DB.traffic).on('value', snap => {
    const d = snap.val(); if (!d) return;
    const sig     = d.signal || 'none';
    const laneA   = d.lane_a_count    ?? 0;
    const laneAPM = d.lane_a_per_min  ?? 0;
    const laneAStat = d.lane_a_status || 'clear';
    const laneB   = d.lane_b_count    ?? 0;
    const laneBPM = d.lane_b_per_min  ?? 0;
    const laneBStat = d.lane_b_status || 'clear';
    const total   = d.total_vehicles  ?? (laneA + laneB);
    const dur     = d.signal_duration_sec ?? '';
    const mode    = d.mode || 'auto';

    // Signal lights (2 lanes only)
    if (typeof tlStates !== 'undefined') {
      if      (sig === 'green_a')  { tlStates[0]={r:false,y:false,g:true};  tlStates[1]={r:true, y:false,g:false}; }
      else if (sig === 'yellow_a') { tlStates[0]={r:false,y:true, g:false}; tlStates[1]={r:true, y:false,g:false}; }
      else if (sig === 'green_b')  { tlStates[0]={r:true, y:false,g:false}; tlStates[1]={r:false,y:false,g:true};  }
      else if (sig === 'yellow_b') { tlStates[0]={r:true, y:false,g:false}; tlStates[1]={r:false,y:true, g:false}; }
      else if (sig === 'red_all')  { tlStates[0]={r:true, y:false,g:false}; tlStates[1]={r:true, y:false,g:false}; }
      if (typeof tlCounts !== 'undefined') { tlCounts[0] = laneA; tlCounts[1] = laneB; }
      if (typeof buildTL === 'function') buildTL();
    }

    // Stat cards (per-min values for live feel)
    const elA  = document.getElementById('traffic-lane-a-count');   if(elA) elA.textContent = laneAPM + '/min';
    const elB  = document.getElementById('traffic-lane-b-count');   if(elB) elB.textContent = laneBPM + '/min';
    const elT  = document.getElementById('traffic-total-count');    if(elT) elT.textContent = total;
    const elS  = document.getElementById('traffic-signal-state');
    if(elS) elS.textContent = (sig==='none'?'AUTO':sig).replace(/_/g,' ').toUpperCase();

    // Lane status details
    const elStA = document.getElementById('traffic-lane-a-status');
    if(elStA){elStA.textContent=laneAStat.toUpperCase();elStA.style.color=laneAStat==='congested'?'var(--red)':laneAStat==='moderate'?'var(--amber)':'var(--green)';}
    const elStB = document.getElementById('traffic-lane-b-status');
    if(elStB){elStB.textContent=laneBStat.toUpperCase();elStB.style.color=laneBStat==='congested'?'var(--red)':laneBStat==='moderate'?'var(--amber)':'var(--green)';}
    const elATd = document.getElementById('traffic-lane-a-today');  if(elATd) elATd.textContent = laneA + ' vehicles';
    const elBTd = document.getElementById('traffic-lane-b-today');  if(elBTd) elBTd.textContent = laneB + ' vehicles';

    const elDur = document.getElementById('traffic-signal-duration');
    if(elDur && dur) elDur.textContent = `${dur}s green · mode: ${mode}`;

    // Alert bar (either lane congested)
    const alertBar=document.getElementById('traffic-alert-bar');
    const alertMsg=document.getElementById('traffic-alert-msg');
    if(alertBar){
      if(laneAStat==='congested' || laneBStat==='congested'){
        alertBar.style.display='';
        if(alertMsg){
          const laneName = laneAStat==='congested' ? 'Lane A' : 'Lane B';
          const pm = laneAStat==='congested' ? laneAPM : laneBPM;
          alertMsg.textContent = `${laneName} congested — ${pm} vehicles/min · Signal extended`;
        }
      } else {
        alertBar.style.display='none';
      }
    }

    // Auto button sync
    const autoBtn = document.getElementById('btn-tl-auto');
    if(autoBtn){if(typeof tlAuto!=='undefined')tlAuto=(mode==='auto');autoBtn.textContent=`🔄 Auto: ${mode==='auto'?'ON':'OFF'}`;}

    // Dashboard module card
    const mcTraffic = document.getElementById('mc-traffic-status');
    if (mcTraffic) {
      mcTraffic.textContent = mode === 'auto' ? 'Auto Mode' : 'Manual';
    }

    // Live chart — real data for BOTH lanes
    if (typeof pushChartLive === 'function') {
      pushChartLive('traffic-chart', [laneAPM, laneBPM]);
    }
  });
}

// ════════════════════════════════════════════════
//  WASTE LISTENER
// ════════════════════════════════════════════════
function startWasteListener() {
  if (!db) return;
  db.ref(DB.waste).on('value', snap => {
    const d = snap.val(); if (!d) return;
    const pct1=d.bin1_level??0, pct2=d.bin2_level??0;
    const stat1=d.bin1_status||'empty', stat2=d.bin2_status||'empty';

    // Update bins array
    if (typeof bins !== 'undefined') {
      bins[0].p=pct1; bins[0].cls=pct1>90?'c':pct1>70?'h':pct1>40?'m':'l';
      if(bins[1]){bins[1].p=pct2; bins[1].cls=pct2>90?'c':pct2>70?'h':pct2>40?'m':'l';}
      if(typeof renderBins==='function') renderBins();
    }

    // Live badge
    const liveEl=document.getElementById('waste-bin1-live');
    if(liveEl){liveEl.textContent=`● Live: ${pct1}% (${stat1})`;liveEl.style.color=pct1>80?'var(--red)':pct1>40?'var(--amber)':'var(--green)';}

    // Route badge
    const routeBadge=document.getElementById('waste-route-badge');
    if(routeBadge){const ra=d.route_active||false;routeBadge.textContent=ra?'Active':'Idle';routeBadge.style.color=ra?'var(--green)':'';}

    // Critical alert >90%
    const maxPct=Math.max(pct1,pct2);
    const critBar=document.getElementById('waste-alert-critical');
    const critMsg=document.getElementById('waste-alert-critical-msg');
    if(critBar){
      if(maxPct>90){critBar.style.display='';if(critMsg)critMsg.textContent=(pct1>90&&pct2>90?'Bin #1 & #2':pct1>90?'Bin #1':'Bin #2')+` — ${maxPct}% full. Collect immediately!`;}
      else critBar.style.display='none';
    }

    // Warning alert >80%
    const warnBar=document.getElementById('waste-alert-warn');
    const warnMsg=document.getElementById('waste-alert-warn-msg');
    if(warnBar){
      if(maxPct>80&&maxPct<=90){warnBar.style.display='';if(warnMsg)warnMsg.textContent=(pct1>80&&pct2>80?'Bin #1 & #2':pct1>80?'Bin #1':'Bin #2')+` filling up — Schedule collection today.`;}
      else if(maxPct<=80) warnBar.style.display='none';
    }

    // Dashboard module card
    const mcWaste = document.getElementById('mc-waste-status');
    if (mcWaste) {
      const crit = (pct1>90?1:0) + (pct2>90?1:0);
      mcWaste.textContent = crit > 0 ? crit + ' Critical' : 'All OK';
    }

    // Live trend chart — average bin fill over time
    if (typeof pushChartLive === 'function') {
      pushChartLive('waste-trend', Math.round((pct1 + pct2) / 2));
    }
  });
}

// ════════════════════════════════════════════════
//  STREET LISTENER
// ════════════════════════════════════════════════
function startStreetListener() {
  if (!db) return;
  db.ref(DB.street).on('value', snap => {
    const d = snap.val(); if (!d) return;
    const lux    = d.lux_raw   ?? 0;
    const isDark = d.is_dark   ?? false;
    const motion = d.motion    ?? false;
    const smode  = d.mode      || 'auto';

    // Per-zone live status from ESP
    const zoneAOn   = d.zone_a_on   ?? d.lights_on ?? false;
    const zoneBOn   = d.zone_b_on   ?? false;
    const zoneCOn   = d.zone_c_on   ?? false;
    const zoneBMode = d.zone_b_mode || 'auto';
    const zoneCMode = d.zone_c_mode || 'auto';

    // Update lights array (live zones from ESP)
    if (typeof lights !== 'undefined' && lights.length >= 3) {
      // Zone A
      lights[0].lux    = lux;
      lights[0].motion = motion;
      lights[0].on     = zoneAOn;
      lights[0].mode   = smode;
      // Zone B
      lights[1].on     = zoneBOn;
      lights[1].mode   = zoneBMode;
      // Zone C
      lights[2].on     = zoneCOn;
      lights[2].mode   = zoneCMode;
      // Zone D (simulated — leave as user set)
      if (typeof renderLG === 'function') renderLG();
    }

    // Stat cards
    const elLux = document.getElementById('street-lux-val');
    if (elLux) elLux.textContent = isDark ? '🌙 Dark' : '☀️ Bright';

    const elMode = document.getElementById('street-mode-val');
    if (elMode) {
      const modeMap = {on:'ON', off:'OFF', auto: isDark ? '🌙 Night' : '☀️ Day'};
      elMode.textContent = modeMap[smode] || smode;
      elMode.style.color = smode==='on' ? 'var(--green)' : smode==='off' ? 'var(--red)' : 'var(--teal)';
    }

    const elMotion = document.getElementById('street-motion-val');
    if (elMotion) {
      elMotion.textContent = motion ? '🏃 Yes' : 'None';
      elMotion.style.color = motion ? 'var(--green)' : '';
    }

    // Lights ON count
    const elCount = document.getElementById('lights-on-count');
    if (elCount && typeof lights !== 'undefined') {
      elCount.textContent = lights.filter(l=>l.on).length + '/4';
    }

    // Top mode badge (Zone A's global mode)
    if (typeof setStreetModeBadge === 'function') setStreetModeBadge(smode);

    // Dashboard module card
    const mcStreet = document.getElementById('mc-street-status');
    if (mcStreet) {
      const totalOn = (zoneAOn?1:0) + (zoneBOn?1:0) + (zoneCOn?1:0);
      mcStreet.textContent = totalOn + '/3 ON';
    }

    // Live charts
    if (typeof pushChartLive === 'function') {
      // Brightness: 100% if lights ON, 0% if OFF (step function live)
      const brightness = zoneAOn ? 100 : 0;
      pushChartLive('brightness-chart', brightness);
      // Energy: 0.9 kWh when ON, 0.05 kWh when OFF (approximation)
      pushChartLive('energy-chart', zoneAOn ? 0.9 : 0.05);
    }
  });
}

// ════════════════════════════════════════════════
//  PARK LISTENER
// ════════════════════════════════════════════════
function startParkListener() {
  if (!db) return;
  db.ref(DB.park).on('value', snap => {
    const d = snap.val(); if (!d) return;
    const zA=d.zone_a??null, zB=d.zone_b??null;
    const pA=d.pump_a??false, pB=d.pump_b??false;
    const md=d.mode||'auto';

    // Update parkState
    if(typeof parkState!=='undefined'&&parkState.zones){
      if(zA!==null){parkState.zones[0].p=zA;parkState.zones[0].s=zA<30?'dry':zA>70?'wet':'ok';parkState.zones[0].pump=pA;}
      if(zB!==null){parkState.zones[1].p=zB;parkState.zones[1].s=zB<30?'dry':zB>70?'wet':'ok';parkState.zones[1].pump=pB;}
      parkState.auto=(md==='auto');
      setTxt('park-auto-status',parkState.auto?'AUTO':'MANUAL');
      if(typeof renderSoilGrid==='function')renderSoilGrid();
    }

    // Alert bar
    const alertBar=document.getElementById('park-alert-bar');
    const alertMsg=document.getElementById('park-alert-msg');
    if(alertBar){
      const a=zA??100,b=zB??100;
      if(a<30||b<30){alertBar.style.display='';if(alertMsg)alertMsg.textContent=(a<30&&b<30?'Zone A & B':(a<30?`Zone A (${a}%)`:`Zone B (${b})%`))+' dry — Pump auto-activated!';}
      else alertBar.style.display='none';
    }

    // Sensor status
    const s1=document.getElementById('park-sensor-status');
    if(s1)s1.textContent=`A:${zA??'—'}%  B:${zB??'—'}%  Pumps:${pA?'A ':''}${pB?'B':''}`;
    const s2=document.getElementById('park-sensor-status2');
    if(s2)s2.textContent='Live ● '+new Date().toLocaleTimeString('en-PK',{hour12:false});

    // Dashboard module card
    const mcPark = document.getElementById('mc-park-status');
    if (mcPark) {
      const pumpsActive = (pA?1:0)+(pB?1:0);
      mcPark.textContent = pumpsActive > 0 ? pumpsActive + ' Pump(s) ON' : (md==='auto'?'Auto Mode':'Manual Mode');
    }

    // Live moisture chart — both zones
    if (typeof pushChartLive === 'function') {
      pushChartLive('moisture-chart', [zA ?? 0, zB ?? 0]);
    }
  });
}

// ════════════════════════════════════════════════
//  COMPLAINTS LISTENER
// ════════════════════════════════════════════════
function startComplaintsListener() {
  if (!db) return;
  db.ref(DB.complaints).on('value', snap => {
    const data = snap.val() || {};
    const list = Object.entries(data).map(([k,v]) => ({...v, fbKey:k})).sort((a,b) => (b.createdAt||0) - (a.createdAt||0));
    if (typeof renderComplaintListFromFb === 'function') renderComplaintListFromFb(list);
    if (typeof updateAdminComplaintFeed   === 'function') updateAdminComplaintFeed(list);
    const openCount = list.filter(c => c.status==='open'||c.status==='progress').length;
    const alertEl = document.getElementById('home-alerts-val'); if(alertEl) alertEl.textContent = openCount;
    const alertCard = document.getElementById('home-alerts-card'); if(alertCard) alertCard.style.display = openCount > 0 ? '' : 'none';
    const mc = document.getElementById('mc-complain-open'); if(mc) mc.textContent = openCount + ' Open';
  });
}

async function fbSubmitComplaint(complaint) {
  if (!db) return null;
  const ref = await db.ref(DB.complaints).push({...complaint, createdAt:Date.now()});
  return ref.key;
}

async function fbUpdateComplaintStatus(fbKey, status) {
  if (!db) return;
  await db.ref(DB.complaints + '/' + fbKey).update({ status, updatedAt:Date.now() });
}

async function fbDeleteComplaint(fbKey) {
  if (!db) return;
  await db.ref(DB.complaints + '/' + fbKey).remove();
}

async function fbDeleteUser(uid) {
  if (!db) return;
  await db.ref(DB.users + '/' + uid).remove();
}

// ── DEMO DATA ──────────────────────────────────────
const DEMO = {
  water:   { flow_rate:12.4, total_liters:2840, status:'normal', leak_detected:false },
  weather: { temperature:27.8, humidity:60.1, feels_like:29.2, dew_point:19.3, sensor:'DHT22' },
};
